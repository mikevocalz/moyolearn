require "json"

package = JSON.parse(File.read(File.join(__dir__, "package.json")))

# Nitro V1 builds iOS through SwiftPM (Package.swift). This podspec only lets
# the React Native CLI discover the library; it lists no sources.
Pod::Spec.new do |s|
  s.name         = "NitroFetch"
  s.version      = package["version"]
  s.summary      = package["description"]
  s.homepage     = package["homepage"]
  s.license      = package["license"]
  s.authors      = package["author"]
  s.source       = { :git => "https://github.com/margelo/react-native-nitro-fetch.git", :tag => "#{s.version}" }

  s.ios.deployment_target = "16.0"
  s.osx.deployment_target = "13.0"
  s.tvos.deployment_target = "16.0"
  s.visionos.deployment_target = "1.0"
end
