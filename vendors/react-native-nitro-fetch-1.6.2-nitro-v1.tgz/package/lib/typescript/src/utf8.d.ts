export declare function stringToUTF8(str: string): Uint8Array;
export declare function utf8ToString(bytes: Uint8Array): string;
