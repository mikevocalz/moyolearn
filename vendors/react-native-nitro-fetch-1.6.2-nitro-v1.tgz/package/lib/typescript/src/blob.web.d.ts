export declare function bytesToBlob(bytes: ArrayBuffer, type: string): Blob;
