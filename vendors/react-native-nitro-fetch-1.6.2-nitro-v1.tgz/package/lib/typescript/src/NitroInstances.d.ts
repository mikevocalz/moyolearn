import { NitroFetch as NitroFetchClass, NativeStorage as NativeStorageClass } from './NitroFetch.nitro';
import { NitroCronet as NitroCronetClass } from './NitroCronet.nitro';
export declare const NitroFetch: NitroFetchClass;
export declare const NativeStorage: NativeStorageClass;
export declare const boxedNitroFetch: import("nitro-core").BoxedHybridObject<NitroFetchClass>;
export declare const NitroCronetSingleton: NitroCronetClass;
