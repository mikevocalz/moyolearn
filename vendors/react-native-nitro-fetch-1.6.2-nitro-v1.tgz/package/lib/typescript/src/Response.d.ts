import { NitroHeaders } from './Headers';
import type { NitroHeader } from './NitroFetch.nitro';
export type ResponseType = 'basic' | 'cors' | 'default' | 'error' | 'opaque' | 'opaqueredirect';
export interface NitroResponseInit {
    url: string;
    status: number;
    statusText: string;
    ok: boolean;
    redirected: boolean;
    headers: NitroHeader[] | NitroHeaders;
    bodyBytes?: ArrayBuffer;
    bodyString?: string;
    body?: ReadableStream<Uint8Array<ArrayBuffer>>;
    type?: ResponseType;
}
export declare class NitroResponse {
    readonly url: string;
    readonly ok: boolean;
    readonly status: number;
    readonly statusText: string;
    readonly redirected: boolean;
    readonly headers: NitroHeaders;
    readonly type: ResponseType;
    private _bodyBytes;
    private _bodyString;
    private _bodyStream;
    private _bodyUsed;
    constructor(body?: BodyInit | null, init?: ResponseInit);
    constructor(init: NitroResponseInit);
    get bodyUsed(): boolean;
    get body(): ReadableStream<Uint8Array<ArrayBuffer>> | null;
    private _throwIfBodyUsed;
    private _getBodyBytes;
    private _getBodyString;
    text(): Promise<string>;
    json(): Promise<any>;
    arrayBuffer(): Promise<ArrayBuffer>;
    private _drainStream;
    blob(): Promise<Blob>;
    bytes(): Promise<Uint8Array<ArrayBuffer>>;
    clone(): NitroResponse;
    formData(): Promise<never>;
    static error(): NitroResponse;
    static json(data: unknown, init?: {
        status?: number;
        statusText?: string;
        headers?: Record<string, string> | [string, string][];
    }): NitroResponse;
    static redirect(url: string, status?: number): NitroResponse;
}
