package com.margelo.nitro.nitrofetch

import com.facebook.proguard.annotations.DoNotStrip
import org.chromium.net.UrlRequest as CronetUrlRequest
import java.nio.ByteBuffer

@DoNotStrip
class HybridUrlRequest(
  private val cronetRequest: CronetUrlRequest,
  private val byteBuffer: ByteBuffer
) : HybridUrlRequestSpec() {
  // Nitro V1: every implementation provides the spec's Companion (no statics here).
  companion object : HybridUrlRequestSpec.Companion

  override fun start() {
    cronetRequest.start()
  }

  override fun followRedirect() {
    cronetRequest.followRedirect()
  }

  override fun read() {
    // Prepare buffer for writing (position=0, limit=capacity)
    byteBuffer.clear()
    // Pass to Cronet to fill
    cronetRequest.read(byteBuffer)
  }

  override fun cancel() {
    cronetRequest.cancel()
  }

  override fun isDone(): Boolean {
    return cronetRequest.isDone
  }
}
