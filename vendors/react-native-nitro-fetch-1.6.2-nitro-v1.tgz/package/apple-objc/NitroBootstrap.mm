#import <Foundation/Foundation.h>
#if __has_include(<UIKit/UIKit.h>)
#import <UIKit/UIKit.h>
#endif

// NitroAutoPrefetcher is the Swift class in the NitroFetch target. Under SwiftPM
// this Objective-C++ file lives in its own target (Swift targets cannot hold
// Objective-C), which cannot link against the Swift target that depends on it.
// Look the class up at runtime instead of referencing its symbol.
static void NitroFetchRunAutoPrefetch(void) {
  Class prefetcher = NSClassFromString(@"NitroAutoPrefetcher");
  SEL selector = NSSelectorFromString(@"prefetchOnStart");
  if (prefetcher != Nil && [prefetcher respondsToSelector:selector]) {
    ((void (*)(id, SEL))[prefetcher methodForSelector:selector])(prefetcher, selector);
  }
}

@interface NitroFetchBootstrapper : NSObject @end
@implementation NitroFetchBootstrapper

+ (void)load {
#if __has_include(<UIKit/UIKit.h>)
  if (NSClassFromString(@"UIApplication")) {
    [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidFinishLaunchingNotification
                                                      object:nil queue:nil
                                                  usingBlock:^(__unused NSNotification *note) {
      NitroFetchRunAutoPrefetch();
    }];
    dispatch_async(dispatch_get_main_queue(), ^{
      NitroFetchRunAutoPrefetch();
    });
  }
#endif
}
@end
