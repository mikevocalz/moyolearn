import {
  Android,
  Apple,
  type HybridObject,
} from 'react-native-nitro-modules';

export interface HttpHeader {
  key: string;
  value: string;
}

export interface UrlResponseInfo {
  url: string;
  httpStatusCode: number;
  httpStatusText: string;
  allHeaders: Record<string, string>;
  allHeadersAsList: HttpHeader[];
  urlChain: string[];
  negotiatedProtocol: string;
  proxyServer: string;
  receivedByteCount: number;
  wasCached: boolean;
}

export interface RequestException {
  message: string;
}

@Apple({
  language: 'swift',
  implementation: { className: 'HybridUrlRequest' },
})
@Android({
  language: 'kotlin',
  implementation: { className: 'HybridUrlRequest' },
})
export declare class UrlRequest extends HybridObject {
  start(): void;
  followRedirect(): void;
  read(): void;
  cancel(): void;
  isDone(): boolean;
}

@Apple({
  language: 'swift',
  implementation: { className: 'HybridUrlRequestBuilder' },
})
@Android({
  language: 'kotlin',
  implementation: { className: 'HybridUrlRequestBuilder' },
})
export declare class UrlRequestBuilder extends HybridObject {
  setHttpMethod(httpMethod: string): void;
  addHeader(name: string, value: string): void;
  setUploadBody(body: ArrayBuffer | string): void;
  disableCache(): void;
  disableCookies(): void;
  onSucceeded(callback: (info: UrlResponseInfo) => void): void;
  onFailed(
    callback: (
      info: UrlResponseInfo | undefined,
      error: RequestException
    ) => void
  ): void;
  onCanceled(callback: (info: UrlResponseInfo | undefined) => void): void;
  onRedirectReceived(
    callback: (info: UrlResponseInfo, newLocationUrl: string) => void
  ): void;
  onResponseStarted(callback: (info: UrlResponseInfo) => void): void;
  onReadCompleted(
    callback: (
      info: UrlResponseInfo,
      byteBuffer: ArrayBuffer,
      bytesRead: number
    ) => void
  ): void;
  build(): UrlRequest;
}

// The new streaming client — separate from NitroFetchClient
@Apple({
  language: 'swift',
  implementation: { className: 'HybridNitroCronet' },
})
@Android({
  language: 'kotlin',
  implementation: { className: 'HybridNitroCronet' },
})
export declare class NitroCronet extends HybridObject {
  constructor();

  newUrlRequestBuilder(url: string): UrlRequestBuilder;
}

export * from '#nitro/UrlRequest';
export * from '#nitro/UrlRequestBuilder';
export * from '#nitro/NitroCronet';
