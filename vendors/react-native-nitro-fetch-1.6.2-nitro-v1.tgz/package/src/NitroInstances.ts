import { NitroModules } from 'react-native-nitro-modules';
import {
  NitroFetch as NitroFetchClass,
  NativeStorage as NativeStorageClass,
} from './NitroFetch.nitro';
import { NitroCronet as NitroCronetClass } from './NitroCronet.nitro';

// Create singletons once per JS runtime. Nitro V1 removed
// createHybridObject; the spec classes expose `new` directly.
export const NitroFetch: NitroFetchClass = new NitroFetchClass();

export const NativeStorage: NativeStorageClass = new NativeStorageClass();

export const boxedNitroFetch = NitroModules.box(NitroFetch);

export const NitroCronetSingleton: NitroCronetClass = new NitroCronetClass();
