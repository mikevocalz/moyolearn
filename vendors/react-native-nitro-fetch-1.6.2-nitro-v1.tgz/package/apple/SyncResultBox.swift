import Foundation

/// Carries `requestSync`'s result out of its Task. The DispatchSemaphore
/// orders the single write before the single read.
final class SyncResultBox<T>: @unchecked Sendable {
  var value: Result<T, Error>?
}
