// Nitro V1 builds this target in Swift 6 language mode. The generated request
// and response structs are not Sendable because they hold an ArrayBuffer.
// NitroFetch already copies a request's JS-owned body bytes on the JS thread
// (HybridNitroFetchClient.uploadData) before any Task starts, and every
// response body is an owning copy, so moving these values between threads is
// what 1.6.2 did under Swift 5.
extension NitroRequest: @unchecked Sendable {}
extension NitroResponse: @unchecked Sendable {}
