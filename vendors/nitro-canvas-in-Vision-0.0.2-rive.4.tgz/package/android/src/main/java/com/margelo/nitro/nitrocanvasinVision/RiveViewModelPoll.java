package com.margelo.nitro.nitrocanvasinVision;

import app.rive.runtime.kotlin.core.ViewModelInstance;

/**
 * Reaches `ViewModelInstance.pollChanges`, which is `internal` in rive-android
 * and therefore invisible to Kotlin in this module — the bytecode name carries
 * the module suffix. Java does not see Kotlin's visibility metadata, so the
 * shim is a one-line call through the mangled name.
 *
 * Why it is needed at all: `ViewModelProperty.getValue()` reads a Kotlin-side
 * `StateFlow` cache, not the native property. Writes made natively — a state
 * machine listener's `ListenerViewModelChange`, an artboard data bind — only
 * become visible after `pollChanges` pulls `nativeGetValue` into the cache.
 * `RiveFileController` does this after every state-machine advance; this
 * panel drives `advance` itself, so it must poll itself or every read answers
 * the value the property had at bind time.
 */
public final class RiveViewModelPoll {
    private RiveViewModelPoll() {}

    public static void poll(ViewModelInstance instance) {
        instance.pollChanges$kotlin_release();
    }
}
