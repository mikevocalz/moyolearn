import { Android, type HybridObject } from "nitro-core";
export * from "#nitro/ForgeBluetooth";

/** Android BLE GATT only. No Logitech Muse services or protocol assumed. */
@Android({ language: "kotlin", implementation: { className: "HybridForgeBluetooth", package: ["ble"] } })
export declare class ForgeBluetooth extends HybridObject {
  constructor();
  static readonly isAvailable: boolean;
  isEnabled(): boolean;
  /** Open Android system Bluetooth Settings; does not assert radio was enabled. */
  openBluetoothSettings(): void;
  startScan(): void;
  stopScan(): void;
  getDevicesJson(): string;
  getScanError(): string;
  connect(deviceId: string): Promise<boolean>;
  disconnect(): void;
  isConnected(): boolean;
  /** Actual discovered attributes only; no vendor protocol or input decoding. */
  discoverGattServices(): Promise<string>;
  readGattCharacteristic(characteristicKey: string): Promise<string>;
  /** Explicit documented ASA 1.1 host session negotiation, after current version READ. */
  configureSpatialAccessoryHost(): Promise<string>;
  readGattDescriptor(descriptorKey: string): Promise<string>;
  setGattNotification(characteristicKey: string, enabled: boolean): Promise<string>;
  getGattDiagnosticsJson(): string;
  stopGattDiagnostics(): void;
  /** Explicit OS pairing of this selected device; resolves only actual BONDED. */
  requestBond(): Promise<string>;
  isSystemChooserAvailable(): boolean;
  chooseMuseWithSystem(): Promise<string>;
  cancelSystemChooser(): void;
  listAssociatedMuseDevices(): Promise<string>;
}
