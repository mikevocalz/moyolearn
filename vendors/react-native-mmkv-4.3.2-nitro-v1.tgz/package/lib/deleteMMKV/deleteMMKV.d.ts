export declare function deleteMMKV(id: string): boolean;
