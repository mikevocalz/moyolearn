import { MMKVFactory } from './specs/MMKVFactory.nitro';
import { MMKVPlatformContext } from './specs/MMKVPlatformContext.nitro';
export declare function getPlatformContext(): MMKVPlatformContext;
export declare function getMMKVFactory(): MMKVFactory;
