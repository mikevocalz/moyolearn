import type { MMKV } from '../specs/MMKV.nitro';
export declare function getDefaultMMKVInstance(): MMKV;
