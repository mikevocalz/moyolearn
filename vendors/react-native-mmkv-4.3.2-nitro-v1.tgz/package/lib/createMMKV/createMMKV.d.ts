import type { MMKV } from '../specs/MMKV.nitro';
import type { Configuration } from '../specs/MMKVFactory.nitro';
export declare function createMMKV(configuration?: Configuration): MMKV;
