export declare function isTest(): boolean;
