export declare function existsMMKV(id: string): boolean;
