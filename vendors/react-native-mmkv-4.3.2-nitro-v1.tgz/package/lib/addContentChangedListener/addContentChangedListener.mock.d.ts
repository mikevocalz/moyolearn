import type { MMKV } from '../specs/MMKV.nitro';
export declare function addContentChangedListener(_mmkv: MMKV): void;
