import type { MMKV } from '../specs/MMKV.nitro';
export declare function addContentChangedListener(mmkv: MMKV): void;
