export declare const LOCAL_STORAGE_KEY_WILDCARD = "\\";
export declare function getLocalStorage(): Storage;
