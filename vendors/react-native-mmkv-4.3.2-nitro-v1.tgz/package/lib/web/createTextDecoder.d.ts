export declare function createTextDecoder(): TextDecoder;
