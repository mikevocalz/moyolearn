import type { MMKV } from '../specs/MMKV.nitro';
export declare function addMemoryWarningListener(_mmkv: MMKV): void;
