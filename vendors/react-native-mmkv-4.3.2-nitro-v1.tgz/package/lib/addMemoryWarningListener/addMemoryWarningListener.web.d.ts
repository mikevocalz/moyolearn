import type { MMKV } from '../specs/MMKV.nitro';
export declare const addMemoryWarningListener: (_mmkv: MMKV) => void;
