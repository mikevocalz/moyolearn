import type { MMKV } from '../specs/MMKV.nitro';
export declare function addMemoryWarningListener(mmkv: MMKV): void;
