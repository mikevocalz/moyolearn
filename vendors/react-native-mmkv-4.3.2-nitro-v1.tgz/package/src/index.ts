// Installs the Nitro V1 runtime (TurboModule, proxy and dispatcher).
import 'react-native-nitro-modules'

// All types
export type { MMKV } from './specs/MMKV.nitro'
export type {
  Configuration,
  Mode,
  RecoveryStrategy,
} from './specs/MMKVFactory.nitro'

// The create function
export { createMMKV } from './createMMKV/createMMKV'

// Exists + Delete
export { existsMMKV } from './existsMMKV/existsMMKV'
export { deleteMMKV } from './deleteMMKV/deleteMMKV'

// All the hooks
export { useMMKV } from './hooks/useMMKV'
export { useMMKVBoolean } from './hooks/useMMKVBoolean'
export { useMMKVBuffer } from './hooks/useMMKVBuffer'
export { useMMKVNumber } from './hooks/useMMKVNumber'
export { useMMKVObject } from './hooks/useMMKVObject'
export { useMMKVString } from './hooks/useMMKVString'
export { useMMKVListener } from './hooks/useMMKVListener'
export { useMMKVKeys } from './hooks/useMMKVKeys'
