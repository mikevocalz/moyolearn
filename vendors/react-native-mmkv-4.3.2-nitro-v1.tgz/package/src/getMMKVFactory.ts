import { MMKVFactory } from './specs/MMKVFactory.nitro'
import { MMKVPlatformContext } from './specs/MMKVPlatformContext.nitro'

let factory: MMKVFactory | undefined
let platformContext: MMKVPlatformContext | undefined

export function getPlatformContext(): MMKVPlatformContext {
  if (platformContext == null) {
    // Lazy-init the platform-context HybridObject
    platformContext = new MMKVPlatformContext()
  }
  return platformContext
}

export function getMMKVFactory(): MMKVFactory {
  if (factory == null) {
    // Lazy-init the factory HybridObject
    factory = new MMKVFactory()
    const context = getPlatformContext()
    const baseDirectory = context.getBaseDirectory()
    factory.initializeMMKV(baseDirectory)
  }

  return factory
}
