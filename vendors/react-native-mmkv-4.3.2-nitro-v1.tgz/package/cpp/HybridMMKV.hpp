//
//  HybridMMKV.hpp
//  react-native-mmkv
//
//  Created by Marc Rousavy on 21.08.2025.
//

#pragma once

#include <NitroMmkv/Configuration.hpp>
#include <NitroMmkv/HybridMMKVSpec.hpp>
#include "MMKVTypes.hpp"

namespace margelo::nitro::mmkv {

class HybridMMKV final : public HybridMMKVSpec {
public:
  static constexpr auto TAG = "MMKV";

  explicit HybridMMKV(const Configuration& configuration);

public:
  // Properties
  std::string getId() override;
  double getSize() override;
  double getByteSize() override;
  double getLength() override;
  bool getIsReadOnly() override;
  bool getIsEncrypted() override;

public:
  // Methods
  void set(const std::string& key, const std::variant<bool, ArrayBuffer, std::string, double>& value) override;
  std::optional<bool> getBoolean(const std::string& key) override;
  std::optional<std::string> getString(const std::string& key) override;
  std::optional<double> getNumber(const std::string& key) override;
  std::optional<ArrayBuffer> getBuffer(const std::string& key) override;
  bool contains(const std::string& key) override;
  bool remove(const std::string& key) override;
  std::vector<std::string> getAllKeys() override;
  void clearAll() override;
  void recrypt(const std::optional<std::string>& key) override;
  void encrypt(const std::string& key, const std::optional<EncryptionType>& encryptionType) override;
  void decrypt() override;
  void trim() override;
  void checkContentChanged() override;
  Listener addOnValueChangedListener(const Callback<void(const std::string& /* key */)>& onValueChanged) override;
  double importAllFrom(const std::shared_ptr<HybridMMKVSpec>& other) override;

protected:
  size_t getExternalMemorySize() noexcept override;

private:
  static MMKVMode getMMKVMode(const Configuration& config);
  static std::optional<MMKVRecoverStrategic> getRecoveryStrategy(const Configuration& config);

private:
  MMKV* instance;
};

} // namespace margelo::nitro::mmkv
