//
//  MMBuffer+toArrayBuffer.hpp
//  react-native-mmkv
//

#pragma once

#include "MMKVTypes.hpp"
#include <NitroModules/ArrayBuffer.hpp>
#include <memory>

namespace margelo::nitro::mmkv {

/**
 * Moves an MMBuffer into a Nitro V1 `ArrayBuffer` without copying the bytes.
 * The MMBuffer is kept alive by the delete callback and is released together
 * with the last `ArrayBuffer` copy, which is how 4.3.2's `ManagedMMBuffer`
 * subclass owned it before `ArrayBuffer` became a value type.
 */
inline ArrayBuffer toArrayBuffer(MMBuffer&& buffer) {
  if (buffer.length() == 0) {
    return ArrayBuffer::empty();
  }
  auto owner = std::make_shared<MMBuffer>(std::move(buffer));
  auto* data = static_cast<uint8_t*>(owner->getPtr());
  size_t size = owner->length();
  return ArrayBuffer::wrap(data, size, [owner]() mutable { owner.reset(); });
}

} // namespace margelo::nitro::mmkv
