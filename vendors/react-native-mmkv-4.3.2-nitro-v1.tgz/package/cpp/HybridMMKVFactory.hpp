//
//  HybridMMKVFactory.hpp
//  react-native-mmkv
//
//  Created by Marc Rousavy on 21.08.2025.
//

#pragma once

#include <NitroMmkv/HybridMMKVFactorySpec.hpp>

namespace margelo::nitro::mmkv {

class HybridMMKVFactory final : public HybridMMKVFactorySpec {
public:
  static constexpr auto TAG = "MMKVFactory";

  HybridMMKVFactory() = default;

public:
  std::string getDefaultMMKVInstanceId() override;
  void initializeMMKV(const std::string& rootPath) override;

  std::shared_ptr<HybridMMKVSpec> createMMKV(const Configuration& configuration) override;
  bool deleteMMKV(const std::string& id) override;
  bool existsMMKV(const std::string& id) override;
};

} // namespace margelo::nitro::mmkv
