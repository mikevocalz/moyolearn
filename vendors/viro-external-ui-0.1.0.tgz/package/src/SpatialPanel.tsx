import React, { useMemo, useState } from "react";
import {
  ViroGeometry,
  ViroNode,
  ViroQuad,
} from "@reactvision/react-viro";
import {
  MovableNode,
  type MovableProps,
  type Vec3,
} from "@viro-external/core";
import {
  buildCurvedPanelGeometry,
  buildRoundedPanelGeometry,
} from "./geometry";
import {
  PanelHeader,
  type PanelHeaderAction,
} from "./PanelHeader";
import {
  PremiumMaterials,
  registerPremiumMaterials,
} from "./materials";
import { resolveVisualDepth } from "./visual-depth";

export type SpatialPanelShape = "square" | "rounded" | "curved";
export type SpatialPanelVariant = "solid" | "glass";

export type SpatialPanelProps = MovableProps & {
  title?: string;
  subtitle?: string;
  shape?: SpatialPanelShape;
  variant?: SpatialPanelVariant;
  width?: number;
  height?: number;
  cornerRadius?: number;
  curvature?: number;
  segments?: number;
  draggable?: boolean;
  resizable?: boolean;
  defaultPinned?: boolean;
  headerActions?: PanelHeaderAction[];
  showPinAction?: boolean;
  showCloseAction?: boolean;
  onPinnedChange?: (pinned: boolean) => void;
  onClose?: () => void;
  position?: Vec3;
  rotation?: Vec3;
  scale?: Vec3;
  children?: React.ReactNode;
  visualDepth?: import("./visual-depth").XRVisualDepth;
};

export function SpatialPanel({
  title,
  subtitle,
  shape = "rounded",
  variant = "solid",
  width = 1.6,
  height = 1,
  cornerRadius = 0.06,
  curvature = 0.32,
  segments = 36,
  draggable = true,
  resizable = true,
  defaultPinned = true,
  headerActions = [],
  showPinAction = true,
  showCloseAction = true,
  onPinnedChange,
  onClose,
  position,
  rotation,
  scale,
  children,
  visualDepth,
  movable,
  tag,
  dragType,
  dragPlane,
  axisLock,
  onMoveStart,
  onMove,
  onMoveEnd,
  pinchToScale,
}: SpatialPanelProps): React.ReactElement {
  registerPremiumMaterials();
  const depth = resolveVisualDepth(visualDepth);

  const [pinned, setPinned] = useState(defaultPinned);
  const [closed, setClosed] = useState(false);
  const headerHeight = Math.max(0.1, height * 0.11);
  const headerY = height / 2 + headerHeight / 2 + 0.015;

  const rounded = useMemo(
    () =>
      shape === "rounded"
        ? buildRoundedPanelGeometry(
            width,
            height,
            cornerRadius,
            14
          )
        : null,
    [cornerRadius, height, shape, width]
  );

  const curved = useMemo(
    () =>
      shape === "curved"
        ? buildCurvedPanelGeometry(
            width,
            height,
            curvature,
            segments
          )
        : null,
    [curvature, height, segments, shape, width]
  );

  if (closed) return <ViroNode />;

  const actions: PanelHeaderAction[] = [
    ...headerActions,
    ...(showPinAction
      ? [
          {
            id: "pin",
            label: pinned ? "Follow" : "Pin",
            onPress: () => {
              const next = !pinned;
              setPinned(next);
              onPinnedChange?.(next);
            },
          },
        ]
      : []),
    ...(showCloseAction
      ? [
          {
            id: "close",
            label: "×",
            onPress: () => {
              setClosed(true);
              onClose?.();
            },
          },
        ]
      : []),
  ];

  const panelMaterial =
    variant === "glass"
      ? PremiumMaterials.panelGlass
      : PremiumMaterials.panel;

  return (
    <MovableNode
      movable={movable ?? draggable}
      tag={tag ?? "vxp-spatial-panel"}
      dragType={dragType}
      dragPlane={dragPlane}
      axisLock={axisLock}
      onMoveStart={onMoveStart}
      onMove={onMove}
      onMoveEnd={onMoveEnd}
      pinchToScale={pinchToScale ?? resizable}
      position={position}
      scale={scale}
    >
      <ViroNode
        rotation={rotation}
        transformBehaviors={pinned ? undefined : ["billboardY"]}
      >
        {depth.edge ? (
          shape === "square" ? (
            <ViroQuad width={width * depth.edgeScale} height={height * depth.edgeScale} position={[0, 0, depth.edgeOffset]} materials={[PremiumMaterials.panelEdge]} ignoreEventHandling />
          ) : (
            <ViroGeometry
              vertices={(rounded ?? curved)!.vertices.map(([x,y,z]) => [x * depth.edgeScale, y * depth.edgeScale, z + depth.edgeOffset] as [number,number,number])}
              normals={(rounded ?? curved)!.normals}
              texcoords={(rounded ?? curved)!.texcoords}
              triangleIndices={(rounded ?? curved)!.triangleIndices}
              materials={[PremiumMaterials.panelEdge]}
              ignoreEventHandling
            />
          )
        ) : null}
        {shape === "square" ? (
          <ViroQuad
            width={width}
            height={height}
            materials={[panelMaterial]}
          />
        ) : (
          <ViroGeometry
            vertices={(rounded ?? curved)!.vertices}
            normals={(rounded ?? curved)!.normals}
            texcoords={(rounded ?? curved)!.texcoords}
            triangleIndices={(rounded ?? curved)!.triangleIndices}
            materials={[panelMaterial]}
          />
        )}

        {children ? (
          <ViroNode position={[0, 0, 0.012]}>
            {children}
          </ViroNode>
        ) : null}

        {(title || subtitle || actions.length > 0) ? (
          <PanelHeader
            width={width}
            height={headerHeight}
            title={title}
            subtitle={subtitle}
            actions={actions}
            position={[0, headerY, 0.008]}
          />
        ) : null}
      </ViroNode>
    </MovableNode>
  );
}
