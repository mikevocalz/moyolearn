import { createStore, type StoreApi } from "zustand/vanilla";
import type { Snapshot, Store } from "@quickdrawjs/core";
import { compileQuickDrawScene, type SceneResult } from "./scene";

/**
 * One source of truth: the caller's existing QuickDraw Store.
 * This is a derived, read-only Skia presentation bridge. Multiple native
 * canvas views can subscribe to the same derived store, but one owner
 * should create/dispose it per board document.
 */
export interface NativeBoardSceneState {
  readonly scene: SceneResult;
  readonly revision: number;
}
export interface NativeBoardSceneBridgeOptions {
  readonly source: Pick<Store, "getSnapshot" | "listen">;
  /** Caller-owned QuickDraw snapshot encoder: no native Viro dependency. */
  readonly encodeSnapshot: (snapshot: Snapshot) => string;
  /** Must schedule a callback before the next display frame. */
  readonly requestFrame: (callback: (timestampMs: number) => void) => number;
  readonly cancelFrame: (handle: number) => void;
}
export interface NativeBoardSceneBridge {
  readonly state: StoreApi<NativeBoardSceneState>;
  /** Synchronously present the most recent document once; safe for tests. */
  flush(): void;
  /** Detach the store listener and cancel any pending frame. Idempotent. */
  dispose(): void;
}
export function createNativeBoardSceneBridge(options: NativeBoardSceneBridgeOptions): NativeBoardSceneBridge {
  const capture = (): SceneResult => {
    try {
      return compileQuickDrawScene(options.encodeSnapshot(options.source.getSnapshot()));
    } catch {
      // Restored/collaborative documents can contain unknown records, and a
      // host's outline encoder may reject them before the strict compiler runs.
      // Preserve the entire source and select its complete fallback. Never let
      // one record crash the host, or make a partial scene look complete.
      return { kind: "unsupported", reasons: ["Board snapshot or ink outline encoding failed"] };
    }
  };
  const state = createStore<NativeBoardSceneState>(() => ({
    scene: capture(), revision: 1,
  }));
  let disposed = false;
  let frame: number | undefined;

  const flush = () => {
    if (disposed) return;
    if (frame !== undefined) {
      options.cancelFrame(frame);
      frame = undefined;
    }
    // Compute only once per frame. Unsupported records are represented as a
    // fallback scene; the editor document itself is never mutated.
    state.setState((previous) => ({
      scene: capture(), revision: previous.revision + 1,
    }));
  };
  const schedule = () => {
    if (disposed || frame !== undefined) return;
    frame = options.requestFrame(() => {
      frame = undefined;
      flush();
    });
  };
  const unsubscribe = options.source.listen(() => schedule());
  return {
    state,
    flush,
    dispose() {
      if (disposed) return;
      disposed = true;
      if (frame !== undefined) options.cancelFrame(frame);
      frame = undefined;
      unsubscribe();
    },
  };
}
