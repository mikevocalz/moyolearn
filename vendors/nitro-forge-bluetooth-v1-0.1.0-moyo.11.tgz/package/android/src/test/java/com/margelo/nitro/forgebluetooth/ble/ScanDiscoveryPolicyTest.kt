package com.margelo.nitro.forgebluetooth.ble

import org.junit.Assert.*
import org.junit.Test

class ScanDiscoveryPolicyTest {
  @Test fun includesExtendedAdvertisementsWhenAdapterSupportsThem() {
    assertFalse(ScanDiscoveryPolicy.legacyOnly(true))
  }
  @Test fun preservesLegacyFallbackOnUnsupportedAdapters() {
    assertTrue(ScanDiscoveryPolicy.legacyOnly(false))
  }
}
