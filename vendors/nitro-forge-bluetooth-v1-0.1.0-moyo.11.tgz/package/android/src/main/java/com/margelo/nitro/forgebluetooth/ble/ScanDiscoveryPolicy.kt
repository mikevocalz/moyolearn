package com.margelo.nitro.forgebluetooth.ble

/** Android defaults to legacy-only results; ASA requires extended advertisements. */
internal object ScanDiscoveryPolicy {
  fun legacyOnly(extendedAdvertisingSupported: Boolean): Boolean = !extendedAdvertisingSupported
}
