import type { CanvasProducer } from './CanvasProducer'
import type { CanvasSurface } from '../specs/CanvasSurface.nitro'

/**
 * Headless WebGL2 producer for three.js (regular `three`, not `three/webgpu`).
 *
 * Lifecycle mirrors GpuProducer:
 *   attach → setup({renderer,width,height}) → (renderFrame on dirty)* → dispose
 *
 * ponytail: CPU readback path (gl.readPixels → surface.submitFrame). At 1024²
 * RGBA that's 4MB/frame; fine for a single panel on Quest 3 but it'll thermal
 * if you mount many. Upgrade path: bind expo-gl's EGL surface to the
 * AHardwareBuffer / IOSurface that backs CanvasSurface for zero-copy. That
 * lands in native code (Android: EGLImage from AHB; iOS: CVPixelBuffer-backed
 * IOSurface texture). Stays in this file's `renderFrame` once available.
 */
export interface GLES3ProducerInit {
  /** Pass `import * as THREE from 'three'`. Producer instantiates the renderer. */
  three: any

  /**
   * Build the scene. Receives a configured `THREE.WebGLRenderer` (already
   * bound to the headless GL context + target-sized) plus dimensions.
   * Return `render(dt)` — called once per frame after setup.
   */
  setup(args: {
    renderer: any
    width: number
    height: number
  }):
    | Promise<{ render(dt: number): unknown; dispose?(): void }>
    | { render(dt: number): unknown; dispose?(): void }
}

export class GLES3Producer implements CanvasProducer {
  private surface: CanvasSurface | null = null
  private gl: any = null
  private exglCtxId: number | null = null
  private renderer: any = null
  private fboTarget: any = null
  private scene: { render(dt: number): unknown; dispose?(): void } | null = null
  private pixels: Uint8Array | null = null
  private lastT = 0

  constructor(private init: GLES3ProducerInit) {}

  async attach(surface: CanvasSurface): Promise<void> {
    if (this.surface === surface) return

    // Same userAgent guard as GpuProducer — three's GLTFLoader trips on it.
    const nav = (globalThis as any).navigator
    if (nav != null && nav.userAgent == null) {
      try { nav.userAgent = '' } catch {}
    }

    let GLView: any
    try {
      GLView = require('expo-gl').GLView
    } catch {
      throw new Error('GLES3Producer requires expo-gl. Install it to use this producer.')
    }
    const gl = await GLView.createContextAsync()
    this.gl = gl
    this.exglCtxId = (gl as any).__exglCtxId ?? (gl as any).contextId ?? null

    // ponytail: three r163+ throws if `gl instanceof WebGLRenderingContext` is
    // true (i.e. context is WebGL1). expo-gl exposes gl as a
    // WebGLRenderingContext instance even though it's actually WebGL2-capable.
    // Override WebGLRenderingContext with a class whose prototype doesn't match
    // gl's so the instanceof check returns false. Hermes does normal proto-chain
    // instanceof; replacing the global is the simplest reliable path.
    const g = globalThis as any
    function _StubWebGL1() {}
    g.WebGLRenderingContext = _StubWebGL1

    // ponytail: expo-gl hasn't shipped renderbufferStorageMultisample. Three
    // calls it on every render-target setup even with antialias:false (MSAA
    // is on by default for WebGL2 backbuffer + EffectComposer). The native
    // HostFunction throws "isn't implemented yet" — override with defineProperty
    // on both the instance and the prototype so neither path can resolve to
    // native. Stub forwards to non-MSAA renderbufferStorage; visual cost is
    // anti-aliasing off, scene still renders. Drop this when expo-gl ships it.
    const stub = function (
      this: any, target: number, _samples: number, internalformat: number, width: number, height: number,
    ) {
      return this.renderbufferStorage(target, internalformat, width, height)
    }
    try {
      Object.defineProperty(gl as any, 'renderbufferStorageMultisample', {
        value: stub, writable: true, configurable: true, enumerable: false,
      })
    } catch {}
    try {
      const proto = Object.getPrototypeOf(gl)
      if (proto) {
        Object.defineProperty(proto, 'renderbufferStorageMultisample', {
          value: stub, writable: true, configurable: true, enumerable: false,
        })
      }
    } catch {}

    const THREE = this.init.three
    // Fake canvas — three's WebGLRenderer reads width/height/style + event hooks.
    const fakeCanvas = {
      width: surface.width,
      height: surface.height,
      style: {},
      addEventListener: () => {},
      removeEventListener: () => {},
      getContext: () => gl,
      clientHeight: surface.height,
      clientWidth: surface.width,
    }

    const renderer = new THREE.WebGLRenderer({
      canvas: fakeCanvas,
      context: gl,
      antialias: false,
      alpha: true,
    })
    renderer.setSize(surface.width, surface.height, false)
    renderer.setPixelRatio(1)
    this.renderer = renderer

    // ponytail: expo-gl's headless context has no presentable backbuffer, so
    // rendering to FB 0 leaves us with nothing to readPixels. Create our own
    // FBO+color-texture and three renders into it via setRenderTarget(target).
    // readPixels then reads from this FBO (last-bound READ_FRAMEBUFFER).
    const fboTarget = new THREE.WebGLRenderTarget(surface.width, surface.height, {
      depthBuffer: true,
      stencilBuffer: false,
      colorSpace: THREE.SRGBColorSpace,
    })
    renderer.setRenderTarget(fboTarget)
    this.fboTarget = fboTarget

    const setupResult = this.init.setup({
      renderer,
      width: surface.width,
      height: surface.height,
    })
    this.scene = await Promise.resolve(setupResult)

    this.pixels = new Uint8Array(surface.width * surface.height * 4)
    this.surface = surface
    this.lastT = Date.now() / 1000
  }

  renderFrame(): void {
    const surface = this.surface
    const gl = this.gl
    const scene = this.scene
    const pixels = this.pixels
    if (!surface || !gl || !scene || !pixels) return

    const t = Date.now() / 1000
    const dt = Math.min(t - this.lastT, 1 / 30)
    this.lastT = t

    scene.render(dt)

    // ponytail: blocking readback. Three rendered to the default FBO via
    // expo-gl; yank RGBA8 into our preallocated buffer. Top-left origin matches
    // CanvasSurface.submitFrame's contract; GL is bottom-left, so callers
    // should flip on the GPU via the camera (or accept the flip).
    gl.readPixels(0, 0, surface.width, surface.height, gl.RGBA, gl.UNSIGNED_BYTE, pixels)
    gl.endFrameEXP?.()

    surface.submitFrame(pixels.buffer as ArrayBuffer)
  }

  resize(_w: number, _h: number): void {
    // ponytail: surface resize is rare in XR — caller drops and remounts the
    // panel instead. Wire renderer.setSize + reallocate pixels if that changes.
  }

  onPointer(_p: 'down' | 'move' | 'up', _x: number, _y: number): void {}

  dispose(): void {
    try { this.scene?.dispose?.() } catch {}
    try { this.fboTarget?.dispose?.() } catch {}
    try { this.renderer?.dispose?.() } catch {}
    try {
      const { GLView } = require('expo-gl')
      if (this.exglCtxId != null) {
        GLView.destroyContextAsync(this.exglCtxId)
      }
    } catch {}
    this.scene = null
    this.renderer = null
    this.gl = null
    this.exglCtxId = null
    this.pixels = null
    this.surface = null
  }
}
