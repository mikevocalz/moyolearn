import type { CanvasSurface } from '../specs/CanvasSurface.nitro'
import type { CanvasProducer } from './CanvasProducer'

// React Native supplies this monotonic clock; no browser DOM types are required.
declare const performance: { now(): number }

/**
 * Minimal protocol the Rive runtime instance must expose. The consumer
 * adapts whatever @rive-app/react-native version is installed.
 */
export interface RiveRuntime {
  readonly managesOwnFrames?: boolean
  setActive?(active: boolean): void
  pointerCancel?(x: number, y: number): void
  advance(deltaSeconds: number): void
  pointerDown?(x: number, y: number): void
  pointerMove?(x: number, y: number): void
  pointerUp?(x: number, y: number): void
  fireInput?(name: string): void
  setInput?(name: string, value: number | boolean): void
  /** Called by the producer after each advance(); use it to render Rive's frame into the surface. */
  drawInto(surface: CanvasSurface): void
  dispose?(): void
}

export interface RiveProducerInit {
  createRuntime(surface: CanvasSurface): Promise<RiveRuntime>
}

export class RiveProducer implements CanvasProducer {
  private surface: CanvasSurface | null = null
  private rive: RiveRuntime | null = null
  private lastTickAt = 0
  private generation = 0

  get runtime(): RiveRuntime | null { return this.rive }

  get managesOwnFrames(): boolean { return this.rive?.managesOwnFrames ?? false }
  setActive(active: boolean): void { this.rive?.setActive?.(active) }

  constructor(private init: RiveProducerInit) {}

  async attach(surface: CanvasSurface): Promise<void> {
    if (this.surface === surface) return
    const generation = ++this.generation
    const runtime = await this.init.createRuntime(surface)
    if (generation !== this.generation) {
      runtime.dispose?.()
      return
    }
    this.rive?.dispose?.()
    this.rive = runtime
    this.surface = surface
    this.lastTickAt = performance.now()
  }

  renderFrame(): void {
    if (!this.surface || !this.rive || this.managesOwnFrames) return
    const now = performance.now()
    const dt = Math.max(0, Math.min((now - this.lastTickAt) / 1000, 0.1))
    this.lastTickAt = now
    this.rive.advance(dt)
    this.rive.drawInto(this.surface)
    this.surface.markDirty()
  }

  resize(_width: number, _height: number): void {}

  onPointer(phase: 'down' | 'move' | 'up' | 'cancel', x: number, y: number): void {
    if (!this.rive) return
    if (phase === 'down') this.rive.pointerDown?.(x, y)
    else if (phase === 'move') this.rive.pointerMove?.(x, y)
    else if (phase === 'up') this.rive.pointerUp?.(x, y)
    else this.rive.pointerCancel?.(x, y)
  }

  fireTrigger(name: string): void {
    this.rive?.fireInput?.(name)
  }

  setInput(name: string, value: number | boolean): void {
    this.rive?.setInput?.(name, value)
  }

  dispose(): void {
    ++this.generation
    this.rive?.dispose?.()
    this.rive = null
    this.surface = null
  }
}
