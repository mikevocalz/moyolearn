import type { CanvasSurface } from '../specs/CanvasSurface.nitro'
import type { CanvasProducer } from './CanvasProducer'

/**
 * The consumer wires the GPU-buffer import (Dawn IOSurface on Apple, Dawn
 * AHardwareBuffer on Android) since it depends on the installed
 * react-native-wgpu version's import API.
 */
export interface WebGPUProducerInit {
  importSurface(surface: CanvasSurface): Promise<{
    device: GPUDevice
    target: GPUTexture
  }>
  setup(args: {
    device: GPUDevice
    target: GPUTexture
    width: number
    height: number
  }): {
    render(encoder: GPUCommandEncoder, targetView: GPUTextureView): void
    onPointer?(phase: 'down' | 'move' | 'up', x: number, y: number): void
    dispose?(): void
  }
}

export class WebGPUProducer implements CanvasProducer {
  private surface: CanvasSurface | null = null
  private device: GPUDevice | null = null
  private target: GPUTexture | null = null
  private rendered: ReturnType<WebGPUProducerInit['setup']> | null = null

  constructor(private init: WebGPUProducerInit) {}

  async attach(surface: CanvasSurface): Promise<void> {
    if (this.surface === surface) return
    const { device, target } = await this.init.importSurface(surface)
    this.surface = surface
    this.device = device
    this.target = target
    this.rendered = this.init.setup({
      device,
      target,
      width: surface.width,
      height: surface.height,
    })
  }

  renderFrame(): void {
    if (!this.surface || !this.device || !this.target || !this.rendered) return
    const encoder = this.device.createCommandEncoder()
    this.rendered.render(encoder, this.target.createView())
    this.device.queue.submit([encoder.finish()])
    this.surface.markDirty()
  }

  // WebGPU textures are immutable. Reattach after surface.resize().
  resize(_width: number, _height: number): void {}

  onPointer(phase: 'down' | 'move' | 'up', x: number, y: number): void {
    this.rendered?.onPointer?.(phase, x, y)
  }

  dispose(): void {
    this.rendered?.dispose?.()
    this.target?.destroy?.()
    this.device?.destroy?.()
    this.surface = null
    this.device = null
    this.target = null
    this.rendered = null
  }
}
