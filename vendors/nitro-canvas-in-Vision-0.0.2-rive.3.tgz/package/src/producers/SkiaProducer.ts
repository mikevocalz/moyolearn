import type { CanvasSurface } from '../specs/CanvasSurface.nitro'
import type { CanvasProducer } from './CanvasProducer'

/**
 * The consumer wires the SkSurface that wraps the CanvasSurface's backing
 * buffer (Graphite over Dawn on @next; Ganesh over GL/Metal on stable).
 * `SkCanvasLike` is whatever the installed Skia binding's canvas type is.
 */
export interface SkiaProducerInit<SkCanvasLike = unknown> {
  importSurface(surface: CanvasSurface): Promise<{
    getCanvas(): SkCanvasLike
    flush(): void
    release?(): void
  }>
  draw(canvas: SkCanvasLike, width: number, height: number): void
  onPointer?(phase: 'down' | 'move' | 'up', x: number, y: number): void
}

export class SkiaProducer<SkCanvasLike = unknown> implements CanvasProducer {
  private surface: CanvasSurface | null = null
  private sk: Awaited<
    ReturnType<SkiaProducerInit<SkCanvasLike>['importSurface']>
  > | null = null

  constructor(private init: SkiaProducerInit<SkCanvasLike>) {}

  async attach(surface: CanvasSurface): Promise<void> {
    if (this.surface === surface) return
    this.sk = await this.init.importSurface(surface)
    this.surface = surface
  }

  renderFrame(): void {
    if (!this.surface || !this.sk) return
    this.init.draw(this.sk.getCanvas(), this.surface.width, this.surface.height)
    this.sk.flush()
    this.surface.markDirty()
  }

  resize(_width: number, _height: number): void {}

  onPointer(phase: 'down' | 'move' | 'up', x: number, y: number): void {
    this.init.onPointer?.(phase, x, y)
  }

  dispose(): void {
    this.sk?.release?.()
    this.sk = null
    this.surface = null
  }
}
