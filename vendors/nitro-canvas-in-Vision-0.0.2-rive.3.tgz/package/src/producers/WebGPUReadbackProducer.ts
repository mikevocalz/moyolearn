import type { CanvasSurface } from '../specs/CanvasSurface.nitro'
import type { CanvasProducer } from './CanvasProducer'

/**
 * Render-once setup the consumer provides. `target` is owned by the producer
 * (a `rgba8unorm` GPUTexture sized to the surface). The consumer's `render`
 * runs once per frame against the consumer-encoded command buffer.
 */
export interface WebGPUReadbackSetup {
  render(encoder: GPUCommandEncoder, view: GPUTextureView): void
  onPointer?(phase: 'down' | 'move' | 'up', x: number, y: number): void
  dispose?(): void
}

export interface WebGPUReadbackProducerInit {
  /** Provide the WebGPU device the producer should render with. */
  getDevice(): Promise<GPUDevice>
  /** Build the per-attach render closure. */
  setup(args: {
    device: GPUDevice
    width: number
    height: number
    format: 'rgba8unorm'
  }): WebGPUReadbackSetup
}

/**
 * WebGPU producer that renders into a producer-owned `rgba8unorm` texture,
 * reads the pixels back to CPU, and calls `surface.submitFrame()` to push
 * them into the shared AHB / IOSurface. Use this until a zero-copy
 * Dawn `SharedTextureMemory` import shim is available; the consumer's
 * `setup`/`render` shape is stable across the readback → zero-copy upgrade.
 */
export class WebGPUReadbackProducer implements CanvasProducer {
  private surface: CanvasSurface | null = null
  private device: GPUDevice | null = null
  private target: GPUTexture | null = null
  private readbackBuffer: GPUBuffer | null = null
  private readbackBytesPerRow = 0
  private outBytes: Uint8Array | null = null
  private rendered: WebGPUReadbackSetup | null = null
  private frameInFlight = false
  private frameCount = 0
  private lastErrorAt = 0

  constructor(private init: WebGPUReadbackProducerInit) {}

  async attach(surface: CanvasSurface): Promise<void> {
    if (this.surface === surface) return

    const device = await this.init.getDevice()
    const width = surface.width
    const height = surface.height

    const target = device.createTexture({
      size: [width, height],
      format: 'rgba8unorm',
      usage:
        GPUTextureUsage.RENDER_ATTACHMENT |
        GPUTextureUsage.COPY_SRC |
        GPUTextureUsage.TEXTURE_BINDING,
    })

    // copyTextureToBuffer requires bytesPerRow to be a multiple of 256.
    const rowBytes = width * 4
    const bytesPerRow = Math.ceil(rowBytes / 256) * 256
    const readbackBuffer = device.createBuffer({
      size: bytesPerRow * height,
      usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ,
    })

    this.surface = surface
    this.device = device
    this.target = target
    this.readbackBuffer = readbackBuffer
    this.readbackBytesPerRow = bytesPerRow
    this.outBytes = new Uint8Array(rowBytes * height)
    this.rendered = this.init.setup({
      device,
      width,
      height,
      format: 'rgba8unorm',
    })
    console.log(
      `[WebGPUReadbackProducer] attached: ${width}x${height} rowBytes=${rowBytes} bytesPerRow=${bytesPerRow}`
    )
  }

  renderFrame(): void {
    void this.renderFrameAsync()
  }

  /**
   * Async variant used by callers that want to await the readback so the
   * next iteration only starts after this one finishes. This naturally
   * throttles the loop to the WebGPU device's submit + mapAsync rate.
   */
  renderFrameAwait(): Promise<void> {
    return this.renderFrameAsync()
  }

  private async renderFrameAsync(): Promise<void> {
    if (
      !this.surface ||
      !this.device ||
      !this.target ||
      !this.readbackBuffer ||
      !this.outBytes ||
      !this.rendered
    ) {
      return
    }
    // Skip a frame rather than queue up multiple readbacks; mapAsync stalls.
    if (this.frameInFlight) return
    this.frameInFlight = true

    const device = this.device
    const target = this.target
    const buffer = this.readbackBuffer
    const out = this.outBytes
    const width = this.surface.width
    const height = this.surface.height
    const bytesPerRow = this.readbackBytesPerRow
    const rowBytes = width * 4

    try {
      const encoder = device.createCommandEncoder()
      this.rendered.render(encoder, target.createView())
      encoder.copyTextureToBuffer(
        { texture: target },
        { buffer, bytesPerRow },
        [width, height, 1]
      )
      device.queue.submit([encoder.finish()])

      await buffer.mapAsync(GPUMapMode.READ)
      const mapped = new Uint8Array(buffer.getMappedRange())
      if (bytesPerRow === rowBytes) {
        out.set(mapped)
      } else {
        for (let y = 0; y < height; y++) {
          out.set(
            mapped.subarray(y * bytesPerRow, y * bytesPerRow + rowBytes),
            y * rowBytes
          )
        }
      }
      buffer.unmap()

      this.surface.submitFrame(out.buffer as ArrayBuffer)
      this.frameCount++
      if (this.frameCount === 1 || this.frameCount % 60 === 0) {
        const sample = `${out[0] ?? '?'},${out[1] ?? '?'},${out[2] ?? '?'},${out[3] ?? '?'}`
        console.log(
          `[WebGPUReadbackProducer] frame ${this.frameCount} submitted, first px rgba=${sample}`
        )
      }
    } catch (err) {
      const now = Date.now()
      if (now - this.lastErrorAt > 1000) {
        console.error('[WebGPUReadbackProducer] frame error:', err)
        this.lastErrorAt = now
      }
    } finally {
      this.frameInFlight = false
    }
  }

  resize(_width: number, _height: number): void {}

  onPointer(phase: 'down' | 'move' | 'up', x: number, y: number): void {
    this.rendered?.onPointer?.(phase, x, y)
  }

  dispose(): void {
    this.rendered?.dispose?.()
    this.target?.destroy?.()
    this.readbackBuffer?.destroy?.()
    this.surface = null
    this.device = null
    this.target = null
    this.readbackBuffer = null
    this.outBytes = null
    this.rendered = null
  }
}
