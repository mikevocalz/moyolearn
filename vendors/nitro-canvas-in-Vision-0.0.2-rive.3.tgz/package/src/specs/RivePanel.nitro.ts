import type { HybridObject } from 'react-native-nitro-modules'

export type RiveFit = 'contain' | 'cover' | 'fill'
export type RivePointerPhase = 'down' | 'move' | 'up' | 'cancel'

/** Android Surface renderer. Pointer positions are artboard coordinates. */
export interface RivePanel extends HybridObject<{ android: 'kotlin' }> {
  readonly artboardWidth: number
  readonly artboardHeight: number
  readonly surfaceAttached: boolean
  readonly renderedFrames: number
  readonly error: string | undefined
  pointer(phase: RivePointerPhase, x: number, y: number): void
  setBoolean(name: string, value: boolean): void
  setNumber(name: string, value: number): void
  /** Read/write the artboard's default view model using named binding paths. */
  setString(name: string, value: string): void
  getNumber(name: string): number
  getBoolean(name: string): boolean
  getString(name: string): string
  /** One listener per numeric path. Called only on value changes, after native advance. */
  observeNumber(name: string, callback: ((value: number) => void) | undefined): void
  fireTrigger(name: string): void
  setActive(active: boolean): void
}
