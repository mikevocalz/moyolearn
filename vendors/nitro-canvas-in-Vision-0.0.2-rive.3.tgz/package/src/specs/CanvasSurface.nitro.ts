import type { HybridObject } from 'react-native-nitro-modules'

export type PointerPhase = 'down' | 'move' | 'up'

/** On Android: which import route the native side uses. iOS/visionOS always use IOSurface. */
export type CanvasBackingRoute = 'ahb' | 'surface-texture'

export interface CanvasSurface extends HybridObject<{
  ios: 'swift'
  android: 'kotlin'
}> {
  readonly id: number
  readonly width: number
  readonly height: number
  readonly route: CanvasBackingRoute

  /** Bump the frame seq so Viro re-imports next render. Drive from the producer's own dirty signal, not a per-frame tick. */
  markDirty(): void

  /**
   * CPU-side frame submit: copies `pixels` (tightly packed RGBA8, width*height*4 bytes,
   * top-left origin) into the backing AHardwareBuffer / IOSurface and bumps the frame seq.
   * Use this when the producer cannot render directly into the shared GPU buffer
   * (e.g. WebGPU read-back path). Zero-copy producers should write the buffer
   * themselves and call {@link markDirty} instead.
   */
  submitFrame(pixels: ArrayBuffer): void

  /**
   * Android-only. Returns the underlying AHardwareBuffer* address as a Double
   * (safe — Android user-space addresses sit well below 2^53). The pointer
   * is owned by the surface and stays valid until {@link dispose} is called.
   * Pass into Dawn's `WGPUSharedTextureMemoryAHardwareBufferDescriptor.handle`
   * to mint a `GPUTexture` that aliases this surface — zero-copy producer side
   * of the SSC.
   *
   * Throws on the `surface-texture` route or on platforms other than Android.
   */
  getAHardwareBufferPointer(): number

  /**
   * iOS / visionOS only. Returns the global IOSurfaceID for the surface's
   * IOSurface backing. The peer side recovers the `IOSurfaceRef` via
   * `IOSurfaceLookupFromMachPort` or `IOSurfaceLookup(id)`. Used to thread
   * the surface through Dawn's `WGPUSharedTextureMemoryIOSurfaceDescriptor`
   * for the zero-copy producer.
   *
   * Throws on Android.
   */
  getIOSurfaceID(): number

  resize(width: number, height: number): void

  /** uvX/uvY ∈ [0,1], origin top-left. Native side maps to producer pixels. */
  dispatchInput(phase: PointerPhase, uvX: number, uvY: number): void
}

export interface CanvasSurfaceFactory extends HybridObject<{
  ios: 'swift'
  android: 'kotlin'
}> {
  create(
    width: number,
    height: number,
    scale: number,
    sRGB: boolean,
    androidRoute: CanvasBackingRoute
  ): CanvasSurface
}
