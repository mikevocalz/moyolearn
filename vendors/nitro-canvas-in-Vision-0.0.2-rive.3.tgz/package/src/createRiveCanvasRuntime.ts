import { NitroModules } from 'react-native-nitro-modules'
import type { CanvasSurface } from './specs/CanvasSurface.nitro'
import type { RivePanelFactory } from './specs/RivePanelFactory.nitro'
import type { RivePanel, RiveFit } from './specs/RivePanel.nitro'
import type { RiveRuntime } from './producers/RiveProducer'

export interface RiveCanvasOptions {
  rivBytes: ArrayBuffer
  artboard?: string
  stateMachine?: string
  /** Rendering and pointer mapping must use the same fit; alignment is centered. */
  fit?: RiveFit
}

export interface NativeRiveRuntime extends RiveRuntime {
  readonly panel: RivePanel
}

/** Quest/PICO renderer; allocate the CanvasSurface with androidRoute: 'surface-texture'. */
export async function createRiveCanvasRuntime(
  surface: CanvasSurface, options: RiveCanvasOptions
): Promise<NativeRiveRuntime> {
  if (surface.route !== 'surface-texture') {
    throw new Error("Native Rive requires androidRoute: 'surface-texture'")
  }
  const factory = NitroModules.createHybridObject<RivePanelFactory>('RivePanelFactory')
  const panel = await factory.create(surface.id, options.rivBytes,
    options.artboard, options.stateMachine, options.fit ?? 'contain')
  return {
    panel,
    managesOwnFrames: true,
    advance: () => {},
    drawInto: () => {},
    pointerDown: (x, y) => panel.pointer('down', x, y),
    pointerMove: (x, y) => panel.pointer('move', x, y),
    pointerUp: (x, y) => panel.pointer('up', x, y),
    pointerCancel: (x, y) => panel.pointer('cancel', x, y),
    fireInput: (name) => panel.fireTrigger(name),
    setInput: (name, value) => typeof value === 'boolean'
      ? panel.setBoolean(name, value) : panel.setNumber(name, value),
    setActive: (active) => panel.setActive(active),
    dispose: () => panel.dispose(),
  }
}
