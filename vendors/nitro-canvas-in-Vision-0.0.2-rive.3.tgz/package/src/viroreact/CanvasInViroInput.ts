/**
 * Pointer input for a canvas quad inside a Viro scene.
 *
 * Viro reports hit locations and drag destinations in WORLD space. This hook
 * turns them into panel UV through the panel's current world transform, so the
 * mapping stays right after the panel (or the group it belongs to) is moved or
 * rotated. The previous version fed world coordinates into quad-local math and
 * used the drag destination as a pointer, which only held for an unrotated
 * quad at the origin — and a quad with `onDrag` is moved by Viro, so it also
 * dragged the panel away from under the pointer.
 *
 * Contract with the quad this is spread onto (the returned props do this):
 *   - `dragTransform: 'none'` — Viro computes the drag but moves nothing
 *     (requires the viro fork's dragTransform prop).
 *   - `dragType: 'FixedToPlane'` on the panel's own plane — so each onDrag
 *     report is the live ray/plane intersection, offset by where the press
 *     began (see planeHitFromDrag).
 * Moving the panel belongs to a separate grip with `dragTransform: 'parent'`;
 * this hook never moves anything.
 *
 * SOT: src/viroreact/panelMath.ts · virocore ViroRenderer/VROInputControllerBase.cpp
 * SOT-KEYWORDS: canvas viro input pointer capture world space uv drag plane rive artboard hook
 */
import { useEffect, useMemo, useRef } from 'react'
import type { CanvasSurface } from '../specs/CanvasSurface.nitro'
import {
  PanelPointerCapture,
  artboardFromUv,
  intersectPanel,
  panelPointFromWorld,
  planeHitFromDrag,
  transformPoint,
  type ArtboardMapping,
  type Mat4,
  type PanelPointerEvent,
  type PanelSize,
  type Ray,
  type Vec3,
} from './panelMath'

// Viro ClickState codes. 3 ("clicked") follows 2 and carries nothing new.
const CLICK_DOWN = 1
const CLICK_UP = 2

export interface CanvasInViroInputOptions {
  /** Quad size in metres, as passed to ViroQuad width/height. */
  enabled?: boolean
  /** Change on tracking loss/recenter to cancel an in-flight gesture. */
  resetKey?: unknown
  size: PanelSize
  /**
   * The quad's current world matrix. Recompute it when the owning group's pose
   * changes (on grip release); during a grip drag the panel ignores pointers.
   */
  panelWorld: Mat4
  /** Receives one pointer owner's events in panel UV. */
  onPointer: (event: PanelPointerEvent) => void
  /**
   * Optional live ray per input source, for hosts that expose controller or
   * hand poses. When present it is preferred over drag reports for moves.
   */
  rayForSource?: (source: number) => Ray | null
}

/** Props to spread onto the ViroQuad that shows the canvas. */
export interface CanvasInViroInputProps {
  onHover: (hovering: boolean, position: Vec3, source: number) => void
  onClickState: (state: number, position: Vec3, source: number) => void
  onDrag: (dragToPos: Vec3, source: number) => void
  dragType: 'FixedToPlane'
  dragPlane: { planePoint: Vec3; planeNormal: Vec3; maxDistance: number }
  dragTransform: 'none'
}

export function useCanvasInViroInput(
  options: CanvasInViroInputOptions
): CanvasInViroInputProps {
  const { size, panelWorld, onPointer, rayForSource, enabled = true, resetKey } = options

  const capture = useRef(new PanelPointerCapture()).current
  // The press that started the current gesture, in world space, and the
  // quad's world origin at that moment — the two anchors ViroCore offsets
  // every drag report from.
  const pressRef = useRef<{ hit: Vec3; nodeOrigin: Vec3 } | null>(null)
  const latest = useRef({ size, panelWorld, onPointer, rayForSource, enabled })
  latest.current = { size, panelWorld, onPointer, rayForSource, enabled }

  useEffect(() => {
    return () => {
      const owner = capture.capturedSource
      if (owner !== null) {
        const event = capture.cancel(owner)
        if (event) latest.current.onPointer(event)
      }
      pressRef.current = null
    }
  }, [capture, enabled, resetKey])

  const dragPlane = useMemo(() => {
    const origin = transformPoint(panelWorld, [0, 0, 0])
    // Inverse-transpose normal via transformed tangents, including nested nonuniform scale.
    const x = transformPoint(panelWorld, [1, 0, 0])
    const y = transformPoint(panelWorld, [0, 1, 0])
    const a = x.map((v, i) => v - origin[i]!)
    const b = y.map((v, i) => v - origin[i]!)
    const n: Vec3 = [a[1]! * b[2]! - a[2]! * b[1]!,
      a[2]! * b[0]! - a[0]! * b[2]!, a[0]! * b[1]! - a[1]! * b[0]!]
    const len = Math.hypot(n[0], n[1], n[2]) || 1
    return {
      planePoint: origin,
      planeNormal: [n[0] / len, n[1] / len, n[2] / len] as Vec3,
      maxDistance: 10,
    }
  }, [panelWorld])

  return useMemo<CanvasInViroInputProps>(() => {
    const emit = (e: PanelPointerEvent | null) => {
      if (e) latest.current.onPointer(e)
    }
    const fromWorld = (p: Vec3) =>
      panelPointFromWorld(p, latest.current.panelWorld, latest.current.size)

    return {
      dragType: 'FixedToPlane',
      dragTransform: 'none',
      dragPlane,
      onHover: (hovering, position, _source) => {
        if (!latest.current.enabled || capture.capturedSource !== null) return
        const point = hovering ? fromWorld(position) : null
        emit(point?.inside ? { phase: 'move', uv: point.uv } : { phase: 'cancel', uv: [-1, -1] })
      },
      onClickState: (state, position, source) => {
        if (!latest.current.enabled) return
        if (state === CLICK_DOWN) {
          const e = capture.down(source, fromWorld(position))
          if (e) {
            pressRef.current = {
              hit: position,
              nodeOrigin: transformPoint(latest.current.panelWorld, [0, 0, 0]),
            }
          }
          emit(e)
        } else if (state === CLICK_UP) {
          // A release is reported where the ray now is, which may be off the
          // quad; a missing or off-plane hit ends the gesture as a cancel.
          if (capture.capturedSource === source) {
            emit(capture.up(source, fromWorld(position)))
            pressRef.current = null
          }
        }
      },
      onDrag: (dragToPos, source) => {
        if (!latest.current.enabled || capture.capturedSource !== source) return
        const { rayForSource: ray, panelWorld: world, size: s } = latest.current
        const live = ray?.(source)
        if (live) {
          emit(capture.move(source, intersectPanel(live, world, s)))
          return
        }
        const press = pressRef.current
        if (!press) return
        emit(
          capture.move(
            source,
            fromWorld(planeHitFromDrag(dragToPos, press.nodeOrigin, press.hit))
          )
        )
      },
    }
  }, [capture, dragPlane])
}

/**
 * Sink that forwards UV events to the surface's native input channel.
 * `PointerPhase` has no cancel, so a cancel is sent as an `up` well outside
 * 0..1: a producer hit-tests it as a release off every control, which is what
 * cancel means.
 */
export function surfacePointerSink(
  surface: CanvasSurface
): (e: PanelPointerEvent) => void {
  return (e) => {
    if (e.phase === 'cancel') surface.dispatchInput('up', -1, -1)
    else surface.dispatchInput(e.phase, e.uv[0], e.uv[1])
  }
}

/** A pointer in artboard units, after the surface's fit/alignment is undone. */
export interface ArtboardPointerEvent {
  phase: PanelPointerEvent['phase']
  x: number
  y: number
}

/**
 * Sink that maps UV to Rive artboard coordinates through the same fit and
 * alignment the artboard is drawn with. A press that lands in letterbox
 * margin is not forwarded, so the margin never counts as artwork; once a
 * press is forwarded its moves and release follow it even into the margin.
 */
export function artboardPointerSink(
  mapping: ArtboardMapping,
  onArtboardPointer: (e: ArtboardPointerEvent) => void
): (e: PanelPointerEvent) => void {
  let pressed = false
  return (e) => {
    const p = artboardFromUv(e.uv, mapping)
    if (e.phase === 'down') {
      if (!p.onArtboard) return
      pressed = true
    } else if (!pressed && e.phase !== 'cancel' && !(e.phase === 'move' && p.onArtboard)) {
      return
    }
    if (e.phase === 'up' || e.phase === 'cancel') pressed = false
    onArtboardPointer({ phase: e.phase, x: p.x, y: p.y })
  }
}
