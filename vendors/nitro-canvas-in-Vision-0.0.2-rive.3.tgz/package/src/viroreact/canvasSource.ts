import type { CanvasSurface } from '../specs/CanvasSurface.nitro'

export interface CanvasSource {
  canvasSource: number
  width: number
  height: number
}

/** Bind to a ViroMaterial diffuseTexture; use Constant lighting for UI panels. */
export function canvasSource(surface: CanvasSurface): CanvasSource {
  return { canvasSource: surface.id, width: surface.width, height: surface.height }
}
