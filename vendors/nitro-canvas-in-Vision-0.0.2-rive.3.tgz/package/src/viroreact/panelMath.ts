/**
 * Panel geometry for pointer input on a canvas quad inside a Viro scene.
 *
 * Why it exists: Viro reports hits and drag destinations in WORLD space, but a
 * canvas producer (Rive, Skia, WebGPU) wants a point on its own artboard. The
 * old mapping fed world coordinates straight into quad-local math, which only
 * worked while the quad sat unrotated at the world origin. Everything here is
 * pure so it can be tested without a renderer.
 *
 * Conventions are mirrored from ViroCore rather than assumed, because a wrong
 * axis order is invisible until a panel is rotated:
 *   - Euler → quaternion: VROQuaternion::set(x, y, z)       (ViroRenderer/VROQuaternion.cpp)
 *   - quaternion → matrix: VROQuaternion::getMatrix          (same file)
 *   - matrices are column-major, v' = M·v:  VROMatrix4f::multiply
 *   - a node's local transform is T·R·S:     VRONode::doComputeTransform (pivots unused)
 *   - a ViroQuad lies in its local XY plane, centred, facing +Z, with
 *     v = 0 on its TOP edge:                 VROSurface (TL = (u0, v0))
 *   - Rive fit/alignment is rive::computeAlignment; `artboardFromUv` inverts it.
 *
 * SOT: ViroRenderer (virocore) files above · rive-runtime src/math/mat2d.cpp computeAlignment
 * SOT-KEYWORDS: viro panel math ray plane intersection inverse transform uv artboard rive fit alignment letterbox pointer capture
 */

export type Vec3 = readonly [number, number, number]
export type Vec2 = readonly [number, number]
/** Column-major 4×4, as ViroCore stores it. */
export type Mat4 = readonly number[]

/** One node's transform as its Viro props express it. Rotation is in degrees. */
export interface NodePose {
  position?: Vec3
  rotation?: Vec3
  scale?: Vec3
}

export interface Ray {
  origin: Vec3
  direction: Vec3
}

export interface PanelSize {
  width: number
  height: number
}

const DEG = Math.PI / 180

/** Viro's Euler → quaternion, line for line. Returns [x, y, z, w]. */
export function viroQuatFromEulerDeg(rotation: Vec3): [number, number, number, number] {
  const sr = Math.sin(rotation[0] * DEG * 0.5)
  const cr = Math.cos(rotation[0] * DEG * 0.5)
  const sp = Math.sin(rotation[1] * DEG * 0.5)
  const cp = Math.cos(rotation[1] * DEG * 0.5)
  const sy = Math.sin(rotation[2] * DEG * 0.5)
  const cy = Math.cos(rotation[2] * DEG * 0.5)
  const cpcy = cp * cy
  const spcy = sp * cy
  const cpsy = cp * sy
  const spsy = sp * sy
  const x = sr * cpcy - cr * spsy
  const y = cr * spcy + sr * cpsy
  const z = cr * cpsy - sr * spcy
  const w = cr * cpcy + sr * spsy
  const n = Math.hypot(x, y, z, w) || 1
  return [x / n, y / n, z / n, w / n]
}

function matFromQuat(q: readonly [number, number, number, number]): number[] {
  const [X, Y, Z, W] = q
  return [
    1 - 2 * Y * Y - 2 * Z * Z, 2 * X * Y + 2 * Z * W, 2 * X * Z - 2 * Y * W, 0,
    2 * X * Y - 2 * Z * W, 1 - 2 * X * X - 2 * Z * Z, 2 * Z * Y + 2 * X * W, 0,
    2 * X * Z + 2 * Y * W, 2 * Z * Y - 2 * X * W, 1 - 2 * X * X - 2 * Y * Y, 0,
    0, 0, 0, 1,
  ]
}

export function multiply(a: Mat4, b: Mat4): number[] {
  const out = new Array<number>(16).fill(0)
  for (let c = 0; c < 4; c++) {
    for (let r = 0; r < 4; r++) {
      let s = 0
      for (let k = 0; k < 4; k++) s += a[k * 4 + r]! * b[c * 4 + k]!
      out[c * 4 + r] = s
    }
  }
  return out
}

/** T·R·S for one node, matching VRONode::doComputeTransform. */
export function localMatrix(pose: NodePose): number[] {
  const [sx, sy, sz] = pose.scale ?? [1, 1, 1]
  const r = matFromQuat(viroQuatFromEulerDeg(pose.rotation ?? [0, 0, 0]))
  const m = r.slice()
  for (let i = 0; i < 4; i++) {
    m[i] = r[i]! * sx
    m[4 + i] = r[4 + i]! * sy
    m[8 + i] = r[8 + i]! * sz
  }
  const [tx, ty, tz] = pose.position ?? [0, 0, 0]
  m[12] = tx
  m[13] = ty
  m[14] = tz
  return m
}

/** World matrix of the last pose in a root-first chain of ancestors. */
export function worldMatrix(chain: readonly NodePose[]): number[] {
  let m = localMatrix({})
  for (const pose of chain) m = multiply(m, localMatrix(pose))
  return m
}

export function transformPoint(m: Mat4, p: Vec3): [number, number, number] {
  return [
    p[0] * m[0]! + p[1] * m[4]! + p[2] * m[8]! + m[12]!,
    p[0] * m[1]! + p[1] * m[5]! + p[2] * m[9]! + m[13]!,
    p[0] * m[2]! + p[1] * m[6]! + p[2] * m[10]! + m[14]!,
  ]
}

function transformDirection(m: Mat4, d: Vec3): [number, number, number] {
  return [
    d[0] * m[0]! + d[1] * m[4]! + d[2] * m[8]!,
    d[0] * m[1]! + d[1] * m[5]! + d[2] * m[9]!,
    d[0] * m[2]! + d[1] * m[6]! + d[2] * m[10]!,
  ]
}

/**
 * Inverse of an affine transform with a possibly non-uniform scale. Returns
 * null for a degenerate (zero-scale) matrix instead of dividing by zero.
 */
export function invertAffine(m: Mat4): number[] | null {
  const a = m[0]!, b = m[4]!, c = m[8]!
  const d = m[1]!, e = m[5]!, f = m[9]!
  const g = m[2]!, h = m[6]!, i = m[10]!
  const A = e * i - f * h
  const B = -(d * i - f * g)
  const C = d * h - e * g
  const det = a * A + b * B + c * C
  if (Math.abs(det) < 1e-12) return null
  const inv = 1 / det
  const r00 = A * inv
  const r01 = -(b * i - c * h) * inv
  const r02 = (b * f - c * e) * inv
  const r10 = B * inv
  const r11 = (a * i - c * g) * inv
  const r12 = -(a * f - c * d) * inv
  const r20 = C * inv
  const r21 = -(a * h - b * g) * inv
  const r22 = (a * e - b * d) * inv
  const tx = m[12]!, ty = m[13]!, tz = m[14]!
  return [
    r00, r10, r20, 0,
    r01, r11, r21, 0,
    r02, r12, r22, 0,
    -(r00 * tx + r01 * ty + r02 * tz),
    -(r10 * tx + r11 * ty + r12 * tz),
    -(r20 * tx + r21 * ty + r22 * tz),
    1,
  ]
}

export interface PanelPoint {
  /** Quad-local position in metres, origin at the centre, +Y up. */
  local: Vec2
  /** Texture coordinate, origin top-left, as the quad samples it. */
  uv: Vec2
  /** Whether the point falls on the quad (edges inclusive). */
  inside: boolean
}

export function panelPointFromLocal(local: Vec2, size: PanelSize): PanelPoint {
  const u = local[0] / size.width + 0.5
  const v = 0.5 - local[1] / size.height
  // Edges are inclusive, with a sliver of slack: a ray aimed at a corner
  // lands a few ulps outside 0..1 after the inverse transform.
  const e = 1e-9
  return {
    local,
    uv: [u, v],
    inside: u >= -e && u <= 1 + e && v >= -e && v <= 1 + e,
  }
}

/**
 * Map a world-space point that should lie on the panel (a Viro hit location)
 * into panel space. `planeTolerance` rejects a hit that is off the plane by
 * more than that many metres, which is what a hit recorded before the panel
 * moved looks like; it returns null rather than mapping a stale point.
 */
export function panelPointFromWorld(
  worldPoint: Vec3,
  panelWorld: Mat4,
  size: PanelSize,
  planeTolerance = 0.01
): PanelPoint | null {
  const inv = invertAffine(panelWorld)
  if (!inv) return null
  const [x, y, z] = transformPoint(inv, worldPoint)
  // Distance off the plane in world units: local z scaled back by the panel's
  // own z axis length, so a scaled panel does not change the tolerance.
  const zAxisLength = Math.hypot(panelWorld[8]!, panelWorld[9]!, panelWorld[10]!)
  if (Math.abs(z * zAxisLength) > planeTolerance) return null
  return panelPointFromLocal([x, y], size)
}

export interface PanelRayHit extends PanelPoint {
  /** Distance along the ray, in world units. */
  distance: number
  /** True when the ray approaches from the panel's +Z (front) side. */
  frontFacing: boolean
}

/**
 * Intersect a world-space ray with the panel's plane. Null when the ray is
 * parallel to the plane or the plane is behind the ray origin. The hit is
 * returned even when it lands outside the quad, so a captured gesture can
 * clamp it; check `inside` to hit-test.
 */
export function intersectPanel(
  ray: Ray,
  panelWorld: Mat4,
  size: PanelSize
): PanelRayHit | null {
  const inv = invertAffine(panelWorld)
  if (!inv) return null
  const o = transformPoint(inv, ray.origin)
  const d = transformDirection(inv, ray.direction)
  if (Math.abs(d[2]) < 1e-9) return null
  const t = -o[2] / d[2]
  if (t < 0) return null
  const local: Vec2 = [o[0] + d[0] * t, o[1] + d[1] * t]
  const worldHit = transformPoint(panelWorld, [local[0], local[1], 0])
  const distance = Math.hypot(
    worldHit[0] - ray.origin[0],
    worldHit[1] - ray.origin[1],
    worldHit[2] - ray.origin[2]
  )
  return { ...panelPointFromLocal(local, size), distance, frontFacing: o[2] > 0 }
}

/**
 * Where the ray meets the panel's plane during a drag reported by Viro with
 * `dragTransform: 'none'` and `dragType: 'FixedToPlane'` on the panel's own
 * plane. ViroCore reports the node's would-be position
 * `originalNodePosition + (planeIntersect - originalHit)`
 * (VROInputControllerBase::getDragPositionFixedToPlane), so the live
 * intersection is recovered as `dragToPos - originalNodePosition + originalHit`.
 */
export function planeHitFromDrag(
  dragToPos: Vec3,
  nodeWorldPositionAtDown: Vec3,
  worldHitAtDown: Vec3
): [number, number, number] {
  return [
    dragToPos[0] - nodeWorldPositionAtDown[0] + worldHitAtDown[0],
    dragToPos[1] - nodeWorldPositionAtDown[1] + worldHitAtDown[1],
    dragToPos[2] - nodeWorldPositionAtDown[2] + worldHitAtDown[2],
  ]
}

// ---------------------------------------------------------------------------
// UV → artboard (Rive fit / alignment)

export type RiveFit =
  | 'fill'
  | 'contain'
  | 'cover'
  | 'fitWidth'
  | 'fitHeight'
  | 'none'
  | 'scaleDown'

/** Rive alignment, -1..1 on each axis; (0, 0) is centre. */
export type RiveAlignment = Vec2

export interface ArtboardMapping {
  /** Pixel size of the texture the artboard is drawn into. */
  surface: PanelSize
  /** Artboard bounds in artboard units. Origin is usually 0, 0. */
  artboard: { x?: number; y?: number; width: number; height: number }
  fit: RiveFit
  alignment?: RiveAlignment
}

export interface ArtboardPoint {
  x: number
  y: number
  /** False when the point lands in letterbox margin, outside the artwork. */
  onArtboard: boolean
}

function riveScale(fit: RiveFit, frame: PanelSize, content: PanelSize): Vec2 {
  const sx = frame.width / content.width
  const sy = frame.height / content.height
  switch (fit) {
    case 'fill':
      return [sx, sy]
    case 'contain': {
      const s = Math.min(sx, sy)
      return [s, s]
    }
    case 'cover': {
      const s = Math.max(sx, sy)
      return [s, s]
    }
    case 'fitWidth':
      return [sx, sx]
    case 'fitHeight':
      return [sy, sy]
    case 'none':
      return [1, 1]
    case 'scaleDown': {
      const s = Math.min(1, Math.min(sx, sy))
      return [s, s]
    }
  }
}

/**
 * Invert rive::computeAlignment for a surface frame at (0, 0). The forward
 * transform maps an artboard point p to
 *   frameCentre + align·frame/2 + scale·(p - contentLeftTop - content/2 - align·content/2)
 * so this solves that for p.
 */
export function artboardFromUv(uv: Vec2, mapping: ArtboardMapping): ArtboardPoint {
  const { surface, artboard, fit } = mapping
  const [ax, ay] = mapping.alignment ?? [0, 0]
  const content = { width: artboard.width, height: artboard.height }
  const [scaleX, scaleY] = riveScale(fit, surface, content)
  const px = uv[0] * surface.width
  const py = uv[1] * surface.height
  const tx = surface.width / 2 + (ax * surface.width) / 2
  const ty = surface.height / 2 + (ay * surface.height) / 2
  const left = artboard.x ?? 0
  const top = artboard.y ?? 0
  const x = (px - tx) / scaleX + left + content.width / 2 + (ax * content.width) / 2
  const y = (py - ty) / scaleY + top + content.height / 2 + (ay * content.height) / 2
  return {
    x,
    y,
    onArtboard: x >= left && x <= left + content.width && y >= top && y <= top + content.height,
  }
}

// ---------------------------------------------------------------------------
// Pointer capture

export type PanelPointerPhase = 'down' | 'move' | 'up' | 'cancel'

export interface PanelPointerEvent {
  phase: PanelPointerPhase
  uv: Vec2
}

/**
 * One pointer owner per gesture. A press that starts on the panel captures
 * that source; moves from any other source are ignored until release; a
 * captured move that leaves the quad is clamped to its edge rather than
 * dropped, so a slider held past its end keeps tracking. A capture that loses
 * its hit (tracking loss, the ray leaving the plane) ends in 'cancel', which a
 * consumer must treat as release WITHOUT activation.
 */
export class PanelPointerCapture {
  private owner: number | null = null
  private lastUv: Vec2 = [0.5, 0.5]

  get capturedSource(): number | null {
    return this.owner
  }

  down(source: number, point: PanelPoint | null): PanelPointerEvent | null {
    if (this.owner !== null || !point || !point.inside) return null
    this.owner = source
    this.lastUv = point.uv
    return { phase: 'down', uv: point.uv }
  }

  move(source: number, point: PanelPoint | null): PanelPointerEvent | null {
    if (this.owner !== source) return null
    if (!point) return this.cancel(source)
    const uv: Vec2 = [clamp01(point.uv[0]), clamp01(point.uv[1])]
    this.lastUv = uv
    return { phase: 'move', uv }
  }

  up(source: number, point: PanelPoint | null): PanelPointerEvent | null {
    if (this.owner !== source) return null
    this.owner = null
    // A release off the quad is a cancel: Rive treats an up outside a
    // listener as no activation, and reporting it at a clamped edge would
    // click whatever sits on that edge.
    if (!point || !point.inside) return { phase: 'cancel', uv: this.lastUv }
    this.lastUv = point.uv
    return { phase: 'up', uv: point.uv }
  }

  cancel(source: number): PanelPointerEvent | null {
    if (this.owner !== source) return null
    this.owner = null
    return { phase: 'cancel', uv: this.lastUv }
  }
}

function clamp01(n: number): number {
  return Math.max(0, Math.min(1, n))
}
