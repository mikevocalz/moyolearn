// Platform-agnostic state for one CanvasSurface: payload handoff, dirty
// tracking, input queue, process-wide registry. Swift/Kotlin shims own GPU
// allocation; the ViroReact bridge resolves canvasSource ids against the
// registry without a JS round-trip.

#pragma once

#include <atomic>
#include <cstdint>
#include <memory>
#include <mutex>
#include <optional>
#include <unordered_map>
#include <vector>

namespace nitrocanvasinVision {

enum class PointerPhase : uint8_t {
    Down = 0,
    Move = 1,
    Up   = 2,
};

enum class BackingRoute : uint8_t {
    AHardwareBuffer = 0, // Android Route B; iOS/visionOS placeholder.
    SurfaceTexture  = 1, // Android Route A.
};

// Mirrors VROSharedTextureHandle (virocore ViroRenderer/VROExternalSurfaceTexture.h).
// Platform-disjoint: only one of iosurface / ahardwareBuffer / surfaceTextureGLId
// is meaningful per payload.
struct SharedHandlePayload {
    int       width  = 0;
    int       height = 0;
    bool      sRGB   = true;
    uintptr_t iosurface = 0;
    uintptr_t ahardwareBuffer = 0;
    uint32_t  surfaceTextureGLId = 0;
};

struct InputEvent {
    PointerPhase phase;
    float        uvX;
    float        uvY;
    uint64_t     seq;
};

// submitFrame() and consumeIfDirty() may run on different threads (producer
// GPU submission vs Viro render). They sync via _frameSeq / _consumedSeq;
// _payloadMutex covers the payload swap. Input queue is mutex-protected.
class CanvasInViroCore {
public:
    static std::shared_ptr<CanvasInViroCore> allocate(int width, int height,
                                                      bool sRGB, BackingRoute route);

    // Returns nullptr if the surface has been disposed.
    static std::shared_ptr<CanvasInViroCore> lookup(int id);

    ~CanvasInViroCore();

    int  id()     const { return _id; }
    int  width()  const { return _width.load(std::memory_order_relaxed); }
    int  height() const { return _height.load(std::memory_order_relaxed); }
    bool sRGB()   const { return _sRGB; }
    BackingRoute route() const { return _route; }

    void submitFrame(const SharedHandlePayload &payload);

    // Bump dirty without changing payload. Used for Route A (SurfaceTexture)
    // where the GL name is stable but updateTexImage() consumed a new frame.
    void markDirty();

    // Latest payload if changed since the previous call.
    std::optional<SharedHandlePayload> consumeIfDirty();

    // Bumps frame seq so any in-flight consumer payload with stale dims is dropped.
    void resize(int width, int height);

    void dispatchInput(PointerPhase phase, float uvX, float uvY);
    std::vector<InputEvent> drainInputs();

    // Removes from registry and clears payload. Platform GPU buffer is owned
    // by the Swift/Kotlin shim and released separately. Idempotent.
    void dispose();
    bool isDisposed() const { return _disposed.load(std::memory_order_acquire); }

private:
    CanvasInViroCore(int id, int width, int height, bool sRGB, BackingRoute route);
    CanvasInViroCore(const CanvasInViroCore &) = delete;
    CanvasInViroCore &operator=(const CanvasInViroCore &) = delete;

    const int          _id;
    std::atomic<int>   _width;
    std::atomic<int>   _height;
    const bool         _sRGB;
    const BackingRoute _route;

    mutable std::mutex     _payloadMutex;
    SharedHandlePayload    _payload {};
    std::atomic<uint64_t>  _frameSeq    {0};
    std::atomic<uint64_t>  _consumedSeq {0};

    std::mutex             _inputMutex;
    std::vector<InputEvent> _inputQueue;
    std::atomic<uint64_t>  _inputSeq {0};

    std::atomic<bool>      _disposed {false};
};

} // namespace nitrocanvasinVision
