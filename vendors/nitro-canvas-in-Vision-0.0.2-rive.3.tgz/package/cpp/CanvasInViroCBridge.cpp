#include "CanvasInViroCBridge.h"
#include "CanvasInViroCore.h"

using nitrocanvasinVision::CanvasInViroCore;
using nitrocanvasinVision::BackingRoute;
using nitrocanvasinVision::PointerPhase;
using nitrocanvasinVision::SharedHandlePayload;

namespace {

// The Swift/Kotlin HybridObject keeps the core alive via a side-table here;
// the registry inside CanvasInViroCore holds only weak_ptrs, so without
// this strong ref allocate() would return a soon-dangling id.
std::mutex &liveMutex() { static std::mutex m; return m; }
std::unordered_map<int, std::shared_ptr<CanvasInViroCore>> &live() {
    static std::unordered_map<int, std::shared_ptr<CanvasInViroCore>> m;
    return m;
}

std::shared_ptr<CanvasInViroCore> resolve(int id) {
    std::lock_guard<std::mutex> lock(liveMutex());
    auto it = live().find(id);
    if (it == live().end()) return nullptr;
    return it->second;
}

} // namespace

int CIVAllocate(int width, int height, bool sRGB, CIVRoute route) {
    auto core = CanvasInViroCore::allocate(width, height, sRGB,
        route == CIV_ROUTE_AHB ? BackingRoute::AHardwareBuffer
                                : BackingRoute::SurfaceTexture);
    if (!core) return 0;
    int id = core->id();
    std::lock_guard<std::mutex> lock(liveMutex());
    live().emplace(id, std::move(core));
    return id;
}

void CIVSubmitFrame(int id,
                    int width, int height, bool sRGB,
                    uintptr_t iosurface,
                    uintptr_t ahardwareBuffer,
                    uint32_t  surfaceTextureGLId) {
    auto core = resolve(id);
    if (!core) return;
    SharedHandlePayload p;
    p.width  = width;
    p.height = height;
    p.sRGB   = sRGB;
    p.iosurface          = iosurface;
    p.ahardwareBuffer    = ahardwareBuffer;
    p.surfaceTextureGLId = surfaceTextureGLId;
    core->submitFrame(p);
}

void CIVMarkDirty(int id) {
    if (auto core = resolve(id)) core->markDirty();
}

void CIVResize(int id, int width, int height) {
    if (auto core = resolve(id)) core->resize(width, height);
}

void CIVDispatchInput(int id, CIVPhase phase, float uvX, float uvY) {
    if (auto core = resolve(id)) {
        core->dispatchInput(static_cast<PointerPhase>(phase), uvX, uvY);
    }
}

void CIVDispose(int id) {
    std::shared_ptr<CanvasInViroCore> core;
    {
        std::lock_guard<std::mutex> lock(liveMutex());
        auto it = live().find(id);
        if (it == live().end()) return;
        core = std::move(it->second);
        live().erase(it);
    }
    if (core) core->dispose();
}
