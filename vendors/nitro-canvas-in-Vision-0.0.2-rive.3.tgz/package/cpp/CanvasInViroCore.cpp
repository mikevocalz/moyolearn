#include "CanvasInViroCore.h"

namespace nitrocanvasinVision {

namespace {

// Registry holds weak_ptrs so lifetime is owned by the HybridObject, not the map.
std::mutex &registryMutex() {
    static std::mutex m;
    return m;
}

std::unordered_map<int, std::weak_ptr<CanvasInViroCore>> &registry() {
    static std::unordered_map<int, std::weak_ptr<CanvasInViroCore>> r;
    return r;
}

int nextId() {
    static std::atomic<int> counter {1};
    return counter.fetch_add(1, std::memory_order_relaxed);
}

} // namespace

std::shared_ptr<CanvasInViroCore> CanvasInViroCore::allocate(int width, int height,
                                                              bool sRGB, BackingRoute route) {
    int id = nextId();
    auto core = std::shared_ptr<CanvasInViroCore>(
        new CanvasInViroCore(id, width, height, sRGB, route));
    std::lock_guard<std::mutex> lock(registryMutex());
    registry().emplace(id, core);
    return core;
}

std::shared_ptr<CanvasInViroCore> CanvasInViroCore::lookup(int id) {
    std::lock_guard<std::mutex> lock(registryMutex());
    auto it = registry().find(id);
    if (it == registry().end()) return nullptr;
    return it->second.lock();
}

CanvasInViroCore::CanvasInViroCore(int id, int width, int height, bool sRGB, BackingRoute route)
    : _id(id), _width(width), _height(height), _sRGB(sRGB), _route(route) {}

CanvasInViroCore::~CanvasInViroCore() {
    dispose();
}

void CanvasInViroCore::dispose() {
    bool wasAlive = !_disposed.exchange(true, std::memory_order_acq_rel);
    if (!wasAlive) return;

    {
        std::lock_guard<std::mutex> lock(registryMutex());
        registry().erase(_id);
    }
    {
        std::lock_guard<std::mutex> lock(_payloadMutex);
        _payload = {};
    }
    {
        std::lock_guard<std::mutex> lock(_inputMutex);
        _inputQueue.clear();
    }
}

void CanvasInViroCore::submitFrame(const SharedHandlePayload &payload) {
    if (_disposed.load(std::memory_order_acquire)) return;
    {
        std::lock_guard<std::mutex> lock(_payloadMutex);
        _payload = payload;
    }
    _frameSeq.fetch_add(1, std::memory_order_release);
}

void CanvasInViroCore::markDirty() {
    if (_disposed.load(std::memory_order_acquire)) return;
    _frameSeq.fetch_add(1, std::memory_order_release);
}

std::optional<SharedHandlePayload> CanvasInViroCore::consumeIfDirty() {
    if (_disposed.load(std::memory_order_acquire)) return std::nullopt;

    uint64_t frame    = _frameSeq.load(std::memory_order_acquire);
    uint64_t consumed = _consumedSeq.load(std::memory_order_relaxed);
    if (frame == consumed) return std::nullopt;

    SharedHandlePayload out;
    {
        std::lock_guard<std::mutex> lock(_payloadMutex);
        out = _payload;
    }
    _consumedSeq.store(frame, std::memory_order_release);
    return out;
}

void CanvasInViroCore::resize(int width, int height) {
    _width.store(width,  std::memory_order_relaxed);
    _height.store(height, std::memory_order_relaxed);
    _frameSeq.fetch_add(1, std::memory_order_release);
}

void CanvasInViroCore::dispatchInput(PointerPhase phase, float uvX, float uvY) {
    if (_disposed.load(std::memory_order_acquire)) return;
    InputEvent ev { phase, uvX, uvY, _inputSeq.fetch_add(1, std::memory_order_relaxed) };
    std::lock_guard<std::mutex> lock(_inputMutex);
    _inputQueue.push_back(ev);
}

std::vector<InputEvent> CanvasInViroCore::drainInputs() {
    std::vector<InputEvent> out;
    std::lock_guard<std::mutex> lock(_inputMutex);
    out.swap(_inputQueue);
    return out;
}

} // namespace nitrocanvasinVision
