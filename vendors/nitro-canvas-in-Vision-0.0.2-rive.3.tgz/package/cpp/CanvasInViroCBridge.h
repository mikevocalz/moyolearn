// Pure-C facade over CanvasInViroCore for Swift bridging-header import and JNI.

#pragma once

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    CIV_ROUTE_AHB             = 0,
    CIV_ROUTE_SURFACE_TEXTURE = 1,
} CIVRoute;

typedef enum {
    CIV_PHASE_DOWN = 0,
    CIV_PHASE_MOVE = 1,
    CIV_PHASE_UP   = 2,
} CIVPhase;

// Returns the new surface id, or 0 on failure.
int  CIVAllocate(int width, int height, bool sRGB, CIVRoute route);

// Exactly one of iosurface / ahardwareBuffer / surfaceTextureGLId is meaningful.
void CIVSubmitFrame(int id,
                    int width, int height, bool sRGB,
                    uintptr_t iosurface,
                    uintptr_t ahardwareBuffer,
                    uint32_t  surfaceTextureGLId);

// Bump dirty without changing payload (Route A updateTexImage refresh).
void CIVMarkDirty(int id);

void CIVResize(int id, int width, int height);
void CIVDispatchInput(int id, CIVPhase phase, float uvX, float uvY);

// Idempotent. After calling, lookups for this id return absent.
void CIVDispose(int id);

#ifdef __cplusplus
}
#endif
