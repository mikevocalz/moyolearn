# nitro-canvas-in-Vision

A live drawing surface (Skia, WebGPU, Rive) appearing as a texture on a 3D
mesh inside a ViroCore scene, on PICO/Quest, iOS, and visionOS.

The producer (in JS, on Dawn/Metal/Vulkan) renders into a shared GPU buffer
(`IOSurface` on Apple, `AHardwareBuffer` on Android). Viro samples it on the
consumer side via its existing external-texture path: `CVOpenGLESTextureCache`
on iOS, `CVMetalTextureCache` on visionOS, an EGLImage-imported
`GL_TEXTURE_EXTERNAL_OES` on Android. Binding to a material uses a sibling
of Viro's existing `requiresCameraTexture` shader-modifier hook
(`requiresExternalSurfaceTexture` + `surface_texture` sampler name).

## Layout

| Path | What |
|---|---|
| `src/specs/CanvasSurface.nitro.ts` | Nitro HybridObject spec. |
| `src/producers/` | `CanvasProducer` interface + three thin adapters. |
| `src/viroreact/` | `canvasSource(surface)` prop + `useCanvasInViroInput` raycast hook. |
| `cpp/` | Shared state machine + pure-C bridge (consumed by Swift bridging header and JNI). |
| `ios/` | Swift HybridObject + IOSurface allocator. |
| `android/src/main/.../` | Kotlin HybridObject + `HardwareBuffer` / `SurfaceTexture` allocator. |
| `example/DemoScene.tsx` | Rive quad + emissive glb screen. |
| `docs/CANVAS-SOURCE-PROP.md` | The small `@reactvision/react-viro` bridge patch. |

The virocore renderer changes live in
[`expo-pico/patches/virocore/virocore-v2.55.0-nitro-canvas.patch`](../expo-pico/patches/virocore/virocore-v2.55.0-nitro-canvas.patch).

## Usage

```tsx
import {
  createCanvasSurface,
  canvasSource,
  useCanvasInViroInput,
  RiveProducer,
} from 'nitro-canvas-in-Vision'
import { ViroNode, ViroQuad, ViroMaterials } from '@reactvision/react-viro'

function LiveQuad() {
  const surface = useMemo(() => createCanvasSurface({ width: 1024, height: 1024 }), [])
  const producer = useMemo(() => new RiveProducer({ createRuntime: makeRive }), [])

  useEffect(() => {
    producer.attach(surface)
    return () => { producer.dispose(); surface.dispose() }
  }, [producer, surface])

  useEffect(() => {
    ViroMaterials.createMaterials({
      live: { emissive: canvasSource(surface), diffuseColor: '#000' },
    })
  }, [surface])

  const input = useCanvasInViroInput(surface, { width: 0.3, height: 0.3 })

  return (
    <ViroNode position={[0, 0, -1.5]}>
      <ViroQuad width={0.3} height={0.3} materials={['live']} {...input} />
    </ViroNode>
  )
}
```

`makeRive` is consumer-supplied — see "Producers" below.

## Producers

The package ships three `CanvasProducer` adapters that wrap your producer
library and call `surface.markDirty()` after each submit. The library-specific
GPU buffer import is consumer-side: each adapter takes a callback that
resolves a `CanvasSurface` into the producer's native target.

For example, `WebGPUProducer` takes:

```ts
new WebGPUProducer({
  importSurface: async (surface) => ({ device, target }), // your Dawn import
  setup: ({ device, target, width, height }) => ({
    render(encoder, view) { /* your wgsl */ },
  }),
})
```

The reason the import is consumer-side: the call shape depends on the
installed version of `react-native-wgpu` / `@shopify/react-native-skia` /
`@rive-app/react-native` and we want to avoid version-pinning the bridge.

## Build

1. `npm install` (or `bun install`).
2. `npm run specs` — runs nitrogen to generate the Swift/Kotlin HybridObject base classes.
3. Apply the virocore patch and rebuild the AAR / `ViroKit.framework`. See `expo-pico/docs/VIRO-ON-PICO.md`.
4. Apply the `canvasSource` patch to `@reactvision/react-viro`. See `docs/CANVAS-SOURCE-PROP.md`.

## Design notes worth knowing

- `markDirty()` is the only knob. Producers call it after their GPU submit; Viro re-imports on its next frame. Static canvas = zero re-render.
- The cross-API fence is the producer's responsibility (`MTLSharedEvent` or commit+wait on Apple, `EGL_ANDROID_native_fence_sync` or a Vulkan external semaphore on Android).
- Bind through the material's **emissive** channel for displays-on-3D-models so scene lighting doesn't dim the content.
- Match the producer's color space. The `sRGB` flag on `createCanvasSurface` (defaults to true) maps to `MTLPixelFormatBGRA8Unorm_sRGB` / `GL_SRGB8_ALPHA8`.

## License

MIT.
