import type { CanvasSurface } from '../specs/CanvasSurface.nitro';
export interface CanvasSource {
    canvasSource: number;
    width: number;
    height: number;
}
/** Bind to a ViroMaterial diffuseTexture; use Constant lighting for UI panels. */
export declare function canvasSource(surface: CanvasSurface): CanvasSource;
