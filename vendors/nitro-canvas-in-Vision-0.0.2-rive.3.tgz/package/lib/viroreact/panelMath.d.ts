/**
 * Panel geometry for pointer input on a canvas quad inside a Viro scene.
 *
 * Why it exists: Viro reports hits and drag destinations in WORLD space, but a
 * canvas producer (Rive, Skia, WebGPU) wants a point on its own artboard. The
 * old mapping fed world coordinates straight into quad-local math, which only
 * worked while the quad sat unrotated at the world origin. Everything here is
 * pure so it can be tested without a renderer.
 *
 * Conventions are mirrored from ViroCore rather than assumed, because a wrong
 * axis order is invisible until a panel is rotated:
 *   - Euler → quaternion: VROQuaternion::set(x, y, z)       (ViroRenderer/VROQuaternion.cpp)
 *   - quaternion → matrix: VROQuaternion::getMatrix          (same file)
 *   - matrices are column-major, v' = M·v:  VROMatrix4f::multiply
 *   - a node's local transform is T·R·S:     VRONode::doComputeTransform (pivots unused)
 *   - a ViroQuad lies in its local XY plane, centred, facing +Z, with
 *     v = 0 on its TOP edge:                 VROSurface (TL = (u0, v0))
 *   - Rive fit/alignment is rive::computeAlignment; `artboardFromUv` inverts it.
 *
 * SOT: ViroRenderer (virocore) files above · rive-runtime src/math/mat2d.cpp computeAlignment
 * SOT-KEYWORDS: viro panel math ray plane intersection inverse transform uv artboard rive fit alignment letterbox pointer capture
 */
export type Vec3 = readonly [number, number, number];
export type Vec2 = readonly [number, number];
/** Column-major 4×4, as ViroCore stores it. */
export type Mat4 = readonly number[];
/** One node's transform as its Viro props express it. Rotation is in degrees. */
export interface NodePose {
    position?: Vec3;
    rotation?: Vec3;
    scale?: Vec3;
}
export interface Ray {
    origin: Vec3;
    direction: Vec3;
}
export interface PanelSize {
    width: number;
    height: number;
}
/** Viro's Euler → quaternion, line for line. Returns [x, y, z, w]. */
export declare function viroQuatFromEulerDeg(rotation: Vec3): [number, number, number, number];
export declare function multiply(a: Mat4, b: Mat4): number[];
/** T·R·S for one node, matching VRONode::doComputeTransform. */
export declare function localMatrix(pose: NodePose): number[];
/** World matrix of the last pose in a root-first chain of ancestors. */
export declare function worldMatrix(chain: readonly NodePose[]): number[];
export declare function transformPoint(m: Mat4, p: Vec3): [number, number, number];
/**
 * Inverse of an affine transform with a possibly non-uniform scale. Returns
 * null for a degenerate (zero-scale) matrix instead of dividing by zero.
 */
export declare function invertAffine(m: Mat4): number[] | null;
export interface PanelPoint {
    /** Quad-local position in metres, origin at the centre, +Y up. */
    local: Vec2;
    /** Texture coordinate, origin top-left, as the quad samples it. */
    uv: Vec2;
    /** Whether the point falls on the quad (edges inclusive). */
    inside: boolean;
}
export declare function panelPointFromLocal(local: Vec2, size: PanelSize): PanelPoint;
/**
 * Map a world-space point that should lie on the panel (a Viro hit location)
 * into panel space. `planeTolerance` rejects a hit that is off the plane by
 * more than that many metres, which is what a hit recorded before the panel
 * moved looks like; it returns null rather than mapping a stale point.
 */
export declare function panelPointFromWorld(worldPoint: Vec3, panelWorld: Mat4, size: PanelSize, planeTolerance?: number): PanelPoint | null;
export interface PanelRayHit extends PanelPoint {
    /** Distance along the ray, in world units. */
    distance: number;
    /** True when the ray approaches from the panel's +Z (front) side. */
    frontFacing: boolean;
}
/**
 * Intersect a world-space ray with the panel's plane. Null when the ray is
 * parallel to the plane or the plane is behind the ray origin. The hit is
 * returned even when it lands outside the quad, so a captured gesture can
 * clamp it; check `inside` to hit-test.
 */
export declare function intersectPanel(ray: Ray, panelWorld: Mat4, size: PanelSize): PanelRayHit | null;
/**
 * Where the ray meets the panel's plane during a drag reported by Viro with
 * `dragTransform: 'none'` and `dragType: 'FixedToPlane'` on the panel's own
 * plane. ViroCore reports the node's would-be position
 * `originalNodePosition + (planeIntersect - originalHit)`
 * (VROInputControllerBase::getDragPositionFixedToPlane), so the live
 * intersection is recovered as `dragToPos - originalNodePosition + originalHit`.
 */
export declare function planeHitFromDrag(dragToPos: Vec3, nodeWorldPositionAtDown: Vec3, worldHitAtDown: Vec3): [number, number, number];
export type RiveFit = 'fill' | 'contain' | 'cover' | 'fitWidth' | 'fitHeight' | 'none' | 'scaleDown';
/** Rive alignment, -1..1 on each axis; (0, 0) is centre. */
export type RiveAlignment = Vec2;
export interface ArtboardMapping {
    /** Pixel size of the texture the artboard is drawn into. */
    surface: PanelSize;
    /** Artboard bounds in artboard units. Origin is usually 0, 0. */
    artboard: {
        x?: number;
        y?: number;
        width: number;
        height: number;
    };
    fit: RiveFit;
    alignment?: RiveAlignment;
}
export interface ArtboardPoint {
    x: number;
    y: number;
    /** False when the point lands in letterbox margin, outside the artwork. */
    onArtboard: boolean;
}
/**
 * Invert rive::computeAlignment for a surface frame at (0, 0). The forward
 * transform maps an artboard point p to
 *   frameCentre + align·frame/2 + scale·(p - contentLeftTop - content/2 - align·content/2)
 * so this solves that for p.
 */
export declare function artboardFromUv(uv: Vec2, mapping: ArtboardMapping): ArtboardPoint;
export type PanelPointerPhase = 'down' | 'move' | 'up' | 'cancel';
export interface PanelPointerEvent {
    phase: PanelPointerPhase;
    uv: Vec2;
}
/**
 * One pointer owner per gesture. A press that starts on the panel captures
 * that source; moves from any other source are ignored until release; a
 * captured move that leaves the quad is clamped to its edge rather than
 * dropped, so a slider held past its end keeps tracking. A capture that loses
 * its hit (tracking loss, the ray leaving the plane) ends in 'cancel', which a
 * consumer must treat as release WITHOUT activation.
 */
export declare class PanelPointerCapture {
    private owner;
    private lastUv;
    get capturedSource(): number | null;
    down(source: number, point: PanelPoint | null): PanelPointerEvent | null;
    move(source: number, point: PanelPoint | null): PanelPointerEvent | null;
    up(source: number, point: PanelPoint | null): PanelPointerEvent | null;
    cancel(source: number): PanelPointerEvent | null;
}
