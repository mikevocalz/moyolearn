import type { CanvasSurface } from '../specs/CanvasSurface.nitro';
import { type ArtboardMapping, type Mat4, type PanelPointerEvent, type PanelSize, type Ray, type Vec3 } from './panelMath';
export interface CanvasInViroInputOptions {
    /** Quad size in metres, as passed to ViroQuad width/height. */
    enabled?: boolean;
    /** Change on tracking loss/recenter to cancel an in-flight gesture. */
    resetKey?: unknown;
    size: PanelSize;
    /**
     * The quad's current world matrix. Recompute it when the owning group's pose
     * changes (on grip release); during a grip drag the panel ignores pointers.
     */
    panelWorld: Mat4;
    /** Receives one pointer owner's events in panel UV. */
    onPointer: (event: PanelPointerEvent) => void;
    /**
     * Optional live ray per input source, for hosts that expose controller or
     * hand poses. When present it is preferred over drag reports for moves.
     */
    rayForSource?: (source: number) => Ray | null;
}
/** Props to spread onto the ViroQuad that shows the canvas. */
export interface CanvasInViroInputProps {
    onHover: (hovering: boolean, position: Vec3, source: number) => void;
    onClickState: (state: number, position: Vec3, source: number) => void;
    onDrag: (dragToPos: Vec3, source: number) => void;
    dragType: 'FixedToPlane';
    dragPlane: {
        planePoint: Vec3;
        planeNormal: Vec3;
        maxDistance: number;
    };
    dragTransform: 'none';
}
export declare function useCanvasInViroInput(options: CanvasInViroInputOptions): CanvasInViroInputProps;
/**
 * Sink that forwards UV events to the surface's native input channel.
 * `PointerPhase` has no cancel, so a cancel is sent as an `up` well outside
 * 0..1: a producer hit-tests it as a release off every control, which is what
 * cancel means.
 */
export declare function surfacePointerSink(surface: CanvasSurface): (e: PanelPointerEvent) => void;
/** A pointer in artboard units, after the surface's fit/alignment is undone. */
export interface ArtboardPointerEvent {
    phase: PanelPointerEvent['phase'];
    x: number;
    y: number;
}
/**
 * Sink that maps UV to Rive artboard coordinates through the same fit and
 * alignment the artboard is drawn with. A press that lands in letterbox
 * margin is not forwarded, so the margin never counts as artwork; once a
 * press is forwarded its moves and release follow it even into the margin.
 */
export declare function artboardPointerSink(mapping: ArtboardMapping, onArtboardPointer: (e: ArtboardPointerEvent) => void): (e: PanelPointerEvent) => void;
