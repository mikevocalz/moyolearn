import type { CanvasSurface } from '../specs/CanvasSurface.nitro';
import type { CanvasProducer } from './CanvasProducer';
/**
 * Minimal protocol the Rive runtime instance must expose. The consumer
 * adapts whatever @rive-app/react-native version is installed.
 */
export interface RiveRuntime {
    readonly managesOwnFrames?: boolean;
    setActive?(active: boolean): void;
    pointerCancel?(x: number, y: number): void;
    advance(deltaSeconds: number): void;
    pointerDown?(x: number, y: number): void;
    pointerMove?(x: number, y: number): void;
    pointerUp?(x: number, y: number): void;
    fireInput?(name: string): void;
    setInput?(name: string, value: number | boolean): void;
    /** Called by the producer after each advance(); use it to render Rive's frame into the surface. */
    drawInto(surface: CanvasSurface): void;
    dispose?(): void;
}
export interface RiveProducerInit {
    createRuntime(surface: CanvasSurface): Promise<RiveRuntime>;
}
export declare class RiveProducer implements CanvasProducer {
    private init;
    private surface;
    private rive;
    private lastTickAt;
    private generation;
    get runtime(): RiveRuntime | null;
    get managesOwnFrames(): boolean;
    setActive(active: boolean): void;
    constructor(init: RiveProducerInit);
    attach(surface: CanvasSurface): Promise<void>;
    renderFrame(): void;
    resize(_width: number, _height: number): void;
    onPointer(phase: 'down' | 'move' | 'up' | 'cancel', x: number, y: number): void;
    fireTrigger(name: string): void;
    setInput(name: string, value: number | boolean): void;
    dispose(): void;
}
