import type { CanvasSurface } from '../specs/CanvasSurface.nitro';
import type { CanvasProducer } from './CanvasProducer';
/**
 * The consumer wires the SkSurface that wraps the CanvasSurface's backing
 * buffer (Graphite over Dawn on @next; Ganesh over GL/Metal on stable).
 * `SkCanvasLike` is whatever the installed Skia binding's canvas type is.
 */
export interface SkiaProducerInit<SkCanvasLike = unknown> {
    importSurface(surface: CanvasSurface): Promise<{
        getCanvas(): SkCanvasLike;
        flush(): void;
        release?(): void;
    }>;
    draw(canvas: SkCanvasLike, width: number, height: number): void;
    onPointer?(phase: 'down' | 'move' | 'up', x: number, y: number): void;
}
export declare class SkiaProducer<SkCanvasLike = unknown> implements CanvasProducer {
    private init;
    private surface;
    private sk;
    constructor(init: SkiaProducerInit<SkCanvasLike>);
    attach(surface: CanvasSurface): Promise<void>;
    renderFrame(): void;
    resize(_width: number, _height: number): void;
    onPointer(phase: 'down' | 'move' | 'up', x: number, y: number): void;
    dispose(): void;
}
