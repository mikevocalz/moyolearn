import type { CanvasSurface } from '../specs/CanvasSurface.nitro';
/**
 * Renders into a CanvasSurface's shared GPU buffer. Implementations call
 * `surface.markDirty()` after their GPU work is submitted; Viro picks up
 * the new texture on its next render.
 *
 * Lifecycle: attach → (renderFrame on dirty)* → dispose.
 */
export interface CanvasProducer {
    readonly managesOwnFrames?: boolean;
    setActive?(active: boolean): void;
    attach(surface: CanvasSurface): Promise<void>;
    renderFrame(): void;
    resize(width: number, height: number): void;
    onPointer(phase: 'down' | 'move' | 'up', x: number, y: number): void;
    dispose(): void;
}
