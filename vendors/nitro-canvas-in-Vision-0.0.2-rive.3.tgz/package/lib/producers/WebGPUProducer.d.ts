import type { CanvasSurface } from '../specs/CanvasSurface.nitro';
import type { CanvasProducer } from './CanvasProducer';
/**
 * The consumer wires the GPU-buffer import (Dawn IOSurface on Apple, Dawn
 * AHardwareBuffer on Android) since it depends on the installed
 * react-native-wgpu version's import API.
 */
export interface WebGPUProducerInit {
    importSurface(surface: CanvasSurface): Promise<{
        device: GPUDevice;
        target: GPUTexture;
    }>;
    setup(args: {
        device: GPUDevice;
        target: GPUTexture;
        width: number;
        height: number;
    }): {
        render(encoder: GPUCommandEncoder, targetView: GPUTextureView): void;
        onPointer?(phase: 'down' | 'move' | 'up', x: number, y: number): void;
        dispose?(): void;
    };
}
export declare class WebGPUProducer implements CanvasProducer {
    private init;
    private surface;
    private device;
    private target;
    private rendered;
    constructor(init: WebGPUProducerInit);
    attach(surface: CanvasSurface): Promise<void>;
    renderFrame(): void;
    resize(_width: number, _height: number): void;
    onPointer(phase: 'down' | 'move' | 'up', x: number, y: number): void;
    dispose(): void;
}
