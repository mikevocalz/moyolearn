import type { CanvasProducer } from './CanvasProducer';
import type { CanvasSurface } from '../specs/CanvasSurface.nitro';
/**
 * Headless WebGL2 producer for three.js (regular `three`, not `three/webgpu`).
 *
 * Lifecycle mirrors GpuProducer:
 *   attach → setup({renderer,width,height}) → (renderFrame on dirty)* → dispose
 *
 * ponytail: CPU readback path (gl.readPixels → surface.submitFrame). At 1024²
 * RGBA that's 4MB/frame; fine for a single panel on Quest 3 but it'll thermal
 * if you mount many. Upgrade path: bind expo-gl's EGL surface to the
 * AHardwareBuffer / IOSurface that backs CanvasSurface for zero-copy. That
 * lands in native code (Android: EGLImage from AHB; iOS: CVPixelBuffer-backed
 * IOSurface texture). Stays in this file's `renderFrame` once available.
 */
export interface GLES3ProducerInit {
    /** Pass `import * as THREE from 'three'`. Producer instantiates the renderer. */
    three: any;
    /**
     * Build the scene. Receives a configured `THREE.WebGLRenderer` (already
     * bound to the headless GL context + target-sized) plus dimensions.
     * Return `render(dt)` — called once per frame after setup.
     */
    setup(args: {
        renderer: any;
        width: number;
        height: number;
    }): Promise<{
        render(dt: number): unknown;
        dispose?(): void;
    }> | {
        render(dt: number): unknown;
        dispose?(): void;
    };
}
export declare class GLES3Producer implements CanvasProducer {
    private init;
    private surface;
    private gl;
    private exglCtxId;
    private renderer;
    private fboTarget;
    private scene;
    private pixels;
    private lastT;
    constructor(init: GLES3ProducerInit);
    attach(surface: CanvasSurface): Promise<void>;
    renderFrame(): void;
    resize(_w: number, _h: number): void;
    onPointer(_p: 'down' | 'move' | 'up', _x: number, _y: number): void;
    dispose(): void;
}
