import type { CanvasSurface } from '../specs/CanvasSurface.nitro';
import type { CanvasProducer } from './CanvasProducer';
/**
 * Render-once setup the consumer provides. `target` is owned by the producer
 * (a `rgba8unorm` GPUTexture sized to the surface). The consumer's `render`
 * runs once per frame against the consumer-encoded command buffer.
 */
export interface WebGPUReadbackSetup {
    render(encoder: GPUCommandEncoder, view: GPUTextureView): void;
    onPointer?(phase: 'down' | 'move' | 'up', x: number, y: number): void;
    dispose?(): void;
}
export interface WebGPUReadbackProducerInit {
    /** Provide the WebGPU device the producer should render with. */
    getDevice(): Promise<GPUDevice>;
    /** Build the per-attach render closure. */
    setup(args: {
        device: GPUDevice;
        width: number;
        height: number;
        format: 'rgba8unorm';
    }): WebGPUReadbackSetup;
}
/**
 * WebGPU producer that renders into a producer-owned `rgba8unorm` texture,
 * reads the pixels back to CPU, and calls `surface.submitFrame()` to push
 * them into the shared AHB / IOSurface. Use this until a zero-copy
 * Dawn `SharedTextureMemory` import shim is available; the consumer's
 * `setup`/`render` shape is stable across the readback → zero-copy upgrade.
 */
export declare class WebGPUReadbackProducer implements CanvasProducer {
    private init;
    private surface;
    private device;
    private target;
    private readbackBuffer;
    private readbackBytesPerRow;
    private outBytes;
    private rendered;
    private frameInFlight;
    private frameCount;
    private lastErrorAt;
    constructor(init: WebGPUReadbackProducerInit);
    attach(surface: CanvasSurface): Promise<void>;
    renderFrame(): void;
    /**
     * Async variant used by callers that want to await the readback so the
     * next iteration only starts after this one finishes. This naturally
     * throttles the loop to the WebGPU device's submit + mapAsync rate.
     */
    renderFrameAwait(): Promise<void>;
    private renderFrameAsync;
    resize(_width: number, _height: number): void;
    onPointer(phase: 'down' | 'move' | 'up', x: number, y: number): void;
    dispose(): void;
}
