import type { CanvasSurface, CanvasBackingRoute } from './specs/CanvasSurface.nitro';
export interface CreateCanvasSurfaceOptions {
    width: number;
    height: number;
    /** Device scale hint. Defaults to 1. */
    scale?: number;
    /** Match the producer's color space. Defaults to true (sRGB). */
    sRGB?: boolean;
    /** Android-only import route. Defaults to 'ahb' (Route B, zero-copy). */
    androidRoute?: CanvasBackingRoute;
}
/**
 * Allocate a new {@link CanvasSurface} that the ViroReact `canvasSource` prop
 * can bind to a material. The producer (Skia / TypeGPU / Rive) renders into
 * the surface's shared GPU buffer; Viro samples it as a live texture on a 3D
 * mesh.
 *
 * Always pair with `surface.dispose()` on unmount.
 */
export declare function createCanvasSurface(opts: CreateCanvasSurfaceOptions): CanvasSurface;
