import type { CanvasSurface } from './specs/CanvasSurface.nitro';
import type { RivePanel, RiveFit } from './specs/RivePanel.nitro';
import type { RiveRuntime } from './producers/RiveProducer';
export interface RiveCanvasOptions {
    rivBytes: ArrayBuffer;
    artboard?: string;
    stateMachine?: string;
    /** Rendering and pointer mapping must use the same fit; alignment is centered. */
    fit?: RiveFit;
}
export interface NativeRiveRuntime extends RiveRuntime {
    readonly panel: RivePanel;
}
/** Quest/PICO renderer; allocate the CanvasSurface with androidRoute: 'surface-texture'. */
export declare function createRiveCanvasRuntime(surface: CanvasSurface, options: RiveCanvasOptions): Promise<NativeRiveRuntime>;
