import type { HybridObject } from 'react-native-nitro-modules';
import type { RivePanel, RiveFit } from './RivePanel.nitro';
export interface RivePanelFactory extends HybridObject<{
    android: 'kotlin';
}> {
    create(surfaceId: number, bytes: ArrayBuffer, artboard: string | undefined, stateMachine: string | undefined, fit: RiveFit): Promise<RivePanel>;
}
