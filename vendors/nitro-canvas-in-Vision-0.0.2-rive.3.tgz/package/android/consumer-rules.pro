# Viro discovers this optional producer bridge by reflection.
-keep class com.margelo.nitro.nitrocanvasinVision.CanvasSourceSurfaces {
    public static void provideSurface(int, android.view.Surface, int, int);
    public static void revokeSurface(int, android.view.Surface);
}
