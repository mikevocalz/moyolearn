// JNI surface over CanvasInViroCBridge for the Kotlin NativeBridge object.
// Symbol names follow Java_<pkg>_<class>_<method> so RegisterNatives is unneeded.

#include <jni.h>
#include <android/hardware_buffer.h>
#include <android/hardware_buffer_jni.h>
#include <cstring>
#include "CanvasInViroCBridge.h"

extern "C" {

JNIEXPORT jint JNICALL
Java_com_margelo_nitro_nitrocanvasinVision_NativeBridge_nAllocate(
        JNIEnv *, jclass,
        jint width, jint height, jboolean sRGB, jint civRoute) {
    return CIVAllocate(width, height, sRGB == JNI_TRUE,
                       static_cast<CIVRoute>(civRoute));
}

JNIEXPORT void JNICALL
Java_com_margelo_nitro_nitrocanvasinVision_NativeBridge_nSubmitFrameAHB(
        JNIEnv *env, jclass,
        jint id, jint width, jint height, jboolean sRGB,
        jobject hardwareBuffer) {
    AHardwareBuffer *buf = AHardwareBuffer_fromHardwareBuffer(env, hardwareBuffer);
    CIVSubmitFrame(id, width, height, sRGB == JNI_TRUE,
                   0, reinterpret_cast<uintptr_t>(buf), 0u);
}

JNIEXPORT void JNICALL
Java_com_margelo_nitro_nitrocanvasinVision_NativeBridge_nSubmitFrameSurfaceTexture(
        JNIEnv *, jclass,
        jint id, jint width, jint height, jboolean sRGB, jint glId) {
    CIVSubmitFrame(id, width, height, sRGB == JNI_TRUE,
                   0, 0, static_cast<uint32_t>(glId));
}

JNIEXPORT jlong JNICALL
Java_com_margelo_nitro_nitrocanvasinVision_NativeBridge_nGetAHBPointer(
        JNIEnv *env, jclass, jobject hardwareBuffer) {
    AHardwareBuffer *buf = AHardwareBuffer_fromHardwareBuffer(env, hardwareBuffer);
    return reinterpret_cast<jlong>(buf);
}

JNIEXPORT void JNICALL
Java_com_margelo_nitro_nitrocanvasinVision_NativeBridge_nWritePixelsAHB(
        JNIEnv *env, jclass,
        jobject hardwareBuffer, jobject srcDirect, jint width, jint height) {
    AHardwareBuffer *buf = AHardwareBuffer_fromHardwareBuffer(env, hardwareBuffer);
    if (buf == nullptr) return;

    auto *src = reinterpret_cast<const uint8_t *>(env->GetDirectBufferAddress(srcDirect));
    if (src == nullptr) return;

    AHardwareBuffer_Desc desc{};
    AHardwareBuffer_describe(buf, &desc);
    const uint32_t dstStrideBytes = desc.stride * 4u; // RGBA8 -> stride is in pixels

    void *dstVoid = nullptr;
    int rc = AHardwareBuffer_lock(
        buf,
        AHARDWAREBUFFER_USAGE_CPU_WRITE_OFTEN,
        -1, nullptr, &dstVoid);
    if (rc != 0 || dstVoid == nullptr) return;

    auto *dst = static_cast<uint8_t *>(dstVoid);
    const size_t rowBytes = static_cast<size_t>(width) * 4u;
    if (dstStrideBytes == rowBytes) {
        std::memcpy(dst, src, rowBytes * static_cast<size_t>(height));
    } else {
        for (int y = 0; y < height; ++y) {
            std::memcpy(dst + y * dstStrideBytes,
                        src + y * rowBytes,
                        rowBytes);
        }
    }

    AHardwareBuffer_unlock(buf, nullptr);
}

JNIEXPORT void JNICALL
Java_com_margelo_nitro_nitrocanvasinVision_NativeBridge_nMarkDirty(
        JNIEnv *, jclass, jint id) {
    CIVMarkDirty(id);
}

JNIEXPORT void JNICALL
Java_com_margelo_nitro_nitrocanvasinVision_NativeBridge_nResize(
        JNIEnv *, jclass, jint id, jint width, jint height) {
    CIVResize(id, width, height);
}

JNIEXPORT void JNICALL
Java_com_margelo_nitro_nitrocanvasinVision_NativeBridge_nDispatchInput(
        JNIEnv *, jclass, jint id, jint phase, jfloat uvX, jfloat uvY) {
    CIVDispatchInput(id, static_cast<CIVPhase>(phase), uvX, uvY);
}

JNIEXPORT void JNICALL
Java_com_margelo_nitro_nitrocanvasinVision_NativeBridge_nDispose(
        JNIEnv *, jclass, jint id) {
    CIVDispose(id);
}

} // extern "C"
