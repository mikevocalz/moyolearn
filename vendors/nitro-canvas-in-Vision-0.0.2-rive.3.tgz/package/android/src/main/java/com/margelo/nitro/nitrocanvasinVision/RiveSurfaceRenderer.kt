package com.margelo.nitro.nitrocanvasinVision

import android.view.Surface
import app.rive.runtime.kotlin.core.Alignment
import app.rive.runtime.kotlin.core.Artboard
import app.rive.runtime.kotlin.core.File as RiveFile
import app.rive.runtime.kotlin.core.Fit
import app.rive.runtime.kotlin.core.StateMachineInstance
import app.rive.runtime.kotlin.renderers.Renderer
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/** Rive's worker draws; its Choreographer loop is scheduled only while dirty/animating. */
internal class RiveSurfaceRenderer(
    private val file: RiveFile,
    private val artboard: Artboard,
    private val machine: StateMachineInstance?,
    private val fit: Fit,
    private val ownedSurface: Surface,
    private val active: AtomicBoolean,
    private val frames: AtomicLong,
    private val onAdvanced: () -> Unit,
    private val onFailure: (RuntimeException) -> Unit,
) : Renderer(file.rendererType) {
    private val dirty = AtomicBoolean(true)
    private val framePending = AtomicBoolean(false)
    private val retired = AtomicBoolean(false)
    private val released = AtomicBoolean(false)
    @Volatile private var animating = true

    init {
        file.acquire()
        dependencies.add(file)
    }

    @Suppress("DEPRECATION")
    fun attach() {
        // Public API in pinned Rive 11.12.1. We own an independent Surface reference;
        // release happens only in the worker's disposeDependencies, after native teardown.
        setSurface(ownedSurface)
    }

    fun pause() {
        framePending.set(false)
        stop()
    }

    fun wake() {
        if (retired.get() || !active.get()) return
        dirty.set(true)
        if (!isPlaying) start() else scheduleFrame()
    }

    override fun scheduleFrame() {
        if (!retired.get() && active.get() && (dirty.get() || animating)
            && framePending.compareAndSet(false, true)) super.scheduleFrame()
    }

    override fun doFrame(frameTimeNanos: Long) {
        framePending.set(false)
        if (!retired.get() && active.get()) super.doFrame(frameTimeNanos)
    }

    override fun advance(elapsed: Float) {
        synchronized(frameLock) {
            if (retired.get() || !hasCppObject || !active.get()) return
            synchronized(file.lock) {
                try {
                    dirty.set(false)
                    val dt = elapsed.coerceIn(0f, 0.1f)
                    val machineActive = machine?.advance(dt) ?: false
                    val artboardActive = artboard.advance(dt)
                    animating = machineActive || artboardActive
                } catch (error: RuntimeException) {
                    animating = false
                    onFailure(error)
                }
            }
        }
        onAdvanced()
    }

    override fun draw() {
        synchronized(frameLock) {
            if (retired.get() || !hasCppObject || !active.get()) return
            synchronized(file.lock) {
                try {
                    artboard.draw(cppPointer, fit, Alignment.CENTER)
                    frames.incrementAndGet()
                } catch (error: RuntimeException) {
                    animating = false
                    onFailure(error)
                }
            }
        }
    }

    override fun delete() {
        if (!retired.compareAndSet(false, true)) return
        super.delete()
    }

    override fun disposeDependencies() {
        synchronized(frameLock) {
            synchronized(file.lock) {
                super.disposeDependencies()
                if (released.compareAndSet(false, true)) ownedSurface.release()
            }
        }
    }

    /** Construction failed before a native renderer existed. */
    fun releaseUnmade() {
        if (released.compareAndSet(false, true)) {
            synchronized(file.lock) { file.release() }
            dependencies.clear()
            ownedSurface.release()
        }
    }
}
