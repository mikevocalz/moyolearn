package com.margelo.nitro.nitrocanvasinVision;

import android.view.Surface;
import java.util.HashMap;
import java.util.Map;

/**
 * Contract called reflectively by Viro. Viro owns each Surface; producers borrow it.
 * Notifications run on the caller's thread and must not block or perform GL work.
 */
public final class CanvasSourceSurfaces {
    public interface Listener {
        void onSurfaceChanged(Surface surface, int width, int height);
    }

    private static final class Entry {
        final Surface surface;
        final int width;
        final int height;
        Entry(Surface surface, int width, int height) {
            this.surface = surface;
            this.width = width;
            this.height = height;
        }
    }

    private static final Map<Integer, Entry> surfaces = new HashMap<>();
    private static final Map<Integer, Listener> listeners = new HashMap<>();

    private CanvasSourceSurfaces() {}

    public static synchronized void provideSurface(int id, Surface surface, int width, int height) {
        if (id <= 0 || surface == null || width <= 0 || height <= 0) {
            throw new IllegalArgumentException("Invalid canvas Surface");
        }
        Entry previous = surfaces.get(id);
        if (previous != null && previous.surface == surface) return;
        surfaces.put(id, new Entry(surface, width, height));
        Listener listener = listeners.get(id);
        if (listener != null) listener.onSurfaceChanged(surface, width, height);
    }

    /** An old material must never revoke a replacement material's Surface. */
    public static synchronized void revokeSurface(int id, Surface surface) {
        Entry current = surfaces.get(id);
        if (current == null || current.surface != surface) return;
        surfaces.remove(id);
        Listener listener = listeners.get(id);
        if (listener != null) listener.onSurfaceChanged(null, 0, 0);
    }

    public static synchronized void subscribe(int id, Listener listener) {
        Listener previous = listeners.get(id);
        if (previous != null && previous != listener) {
            throw new IllegalStateException("Canvas surface already has a producer: " + id);
        }
        listeners.put(id, listener);
        Entry current = surfaces.get(id);
        try {
            listener.onSurfaceChanged(current == null ? null : current.surface,
                    current == null ? 0 : current.width, current == null ? 0 : current.height);
        } catch (RuntimeException error) {
            listeners.remove(id);
            throw error;
        }
    }

    public static synchronized void unsubscribe(int id, Listener listener) {
        if (listeners.get(id) == listener) listeners.remove(id);
    }
}
