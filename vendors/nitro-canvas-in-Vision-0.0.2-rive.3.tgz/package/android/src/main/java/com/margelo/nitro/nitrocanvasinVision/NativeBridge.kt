package com.margelo.nitro.nitrocanvasinVision

import android.hardware.HardwareBuffer
import java.nio.ByteBuffer

// JNI surface over cpp/CanvasInViroCBridge.h. Method ids in HybridCanvasSurface
// must match the CIVRoute / CIVPhase values in that header.
internal object NativeBridge {
    init { System.loadLibrary("NitroCanvasInVision") }

    @JvmStatic external fun nAllocate(width: Int, height: Int, sRGB: Boolean, civRoute: Int): Int

    @JvmStatic external fun nSubmitFrameAHB(
        id: Int, width: Int, height: Int, sRGB: Boolean, hardwareBuffer: HardwareBuffer
    )
    @JvmStatic external fun nSubmitFrameSurfaceTexture(
        id: Int, width: Int, height: Int, sRGB: Boolean, glId: Int
    )

    // Locks the AHB, swizzle-copies RGBA8 pixels from `srcDirect` (a direct
    // ByteBuffer at least width*height*4 bytes), unlocks. Honors AHB's stride.
    @JvmStatic external fun nWritePixelsAHB(
        hardwareBuffer: HardwareBuffer, srcDirect: ByteBuffer, width: Int, height: Int
    )

    // Returns the native AHardwareBuffer* address (uintptr_t cast to jlong).
    // Used by the zero-copy WebGPU producer to hand the same buffer to Dawn
    // via WGPUSharedTextureMemoryAHardwareBufferDescriptor.
    @JvmStatic external fun nGetAHBPointer(hardwareBuffer: HardwareBuffer): Long

    @JvmStatic external fun nMarkDirty(id: Int)
    @JvmStatic external fun nResize(id: Int, width: Int, height: Int)
    @JvmStatic external fun nDispatchInput(id: Int, phase: Int, uvX: Float, uvY: Float)
    @JvmStatic external fun nDispose(id: Int)
}
