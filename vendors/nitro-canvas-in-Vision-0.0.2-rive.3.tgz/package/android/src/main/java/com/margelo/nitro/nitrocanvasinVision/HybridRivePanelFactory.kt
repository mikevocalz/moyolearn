package com.margelo.nitro.nitrocanvasinVision

import app.rive.runtime.kotlin.core.Rive
import app.rive.runtime.kotlin.core.File as RiveFile
import com.margelo.nitro.NitroModules
import com.margelo.nitro.core.ArrayBuffer
import com.margelo.nitro.core.Promise

@androidx.annotation.Keep
@com.facebook.proguard.annotations.DoNotStrip
internal class HybridRivePanelFactory : HybridRivePanelFactorySpec() {
    override fun create(surfaceId: Double, bytes: ArrayBuffer, artboard: String?,
                        stateMachine: String?, fit: RiveFit): Promise<HybridRivePanelSpec> {
        require(surfaceId.isFinite() && surfaceId > 0 && surfaceId <= Int.MAX_VALUE && surfaceId % 1.0 == 0.0)
        require(bytes.size > 0) { "Rive file is empty" }
        // Copy before crossing threads: JS retains ownership of the input buffer.
        val copy = ByteArray(bytes.size.toInt())
        bytes.getBuffer(false).duplicate().get(copy)
        return Promise.parallel {
            synchronized(Rive::class.java) {
                if (!initialized) {
                    Rive.init(NitroModules.applicationContext
                        ?: error("React Native application context is unavailable"))
                    initialized = true
                }
            }
            val file = RiveFile(copy)
            try {
                HybridRivePanel(surfaceId.toInt(), file, artboard, stateMachine, fit)
            } catch (error: Throwable) {
                file.release()
                throw error
            }
        }
    }

    companion object { private var initialized = false }
}
