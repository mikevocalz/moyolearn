package com.margelo.nitro.nitrocanvasinVision

import android.hardware.HardwareBuffer
import android.os.Build
import com.margelo.nitro.core.ArrayBuffer
import java.util.concurrent.atomic.AtomicBoolean

// Route B (AHardwareBuffer) is zero-copy and fence-friendly via Vulkan
// external memory; Route A (SurfaceTexture) is the smaller integration
// when the producer already drives a Surface.
internal class HybridCanvasSurface(
    private var pixelWidth: Int,
    private var pixelHeight: Int,
    private val isSRGB: Boolean,
    private val storedRoute: CanvasBackingRoute,
    // AHB route: held strong so consumer and producer wraps stay valid.
    private var hardwareBuffer: HardwareBuffer?,
    // SurfaceTexture route: GL name owned outside this module.
    private val surfaceTextureGLId: Int,
) : HybridCanvasSurfaceSpec() {
    private val disposed = AtomicBoolean(false)

    private val surfaceId: Int = NativeBridge.nAllocate(
        pixelWidth, pixelHeight, isSRGB,
        when (storedRoute) {
            CanvasBackingRoute.AHB             -> CIV_ROUTE_AHB
            CanvasBackingRoute.SURFACE_TEXTURE -> CIV_ROUTE_SURFACE_TEXTURE
        }
    )

    init { publishCurrentHandle() }

    override val id: Double = surfaceId.toDouble()
    override val width: Double
        get() = pixelWidth.toDouble()
    override val height: Double
        get() = pixelHeight.toDouble()
    override val route: CanvasBackingRoute = storedRoute

    override fun markDirty() {
        publishCurrentHandle()
    }

    override fun getAHardwareBufferPointer(): Double {
        if (storedRoute != CanvasBackingRoute.AHB) {
            throw IllegalStateException(
                "getAHardwareBufferPointer is only valid on the 'ahb' route."
            )
        }
        val buffer = hardwareBuffer
            ?: throw IllegalStateException("CanvasSurface has no AHardwareBuffer.")
        // Pointer comes back as a 64-bit value but Android user-space addresses
        // sit well below 2^53, so the round-trip through Double is exact.
        return NativeBridge.nGetAHBPointer(buffer).toDouble()
    }

    override fun getIOSurfaceID(): Double {
        throw UnsupportedOperationException("getIOSurfaceID is iOS-only.")
    }

    override fun submitFrame(pixels: ArrayBuffer) {
        if (storedRoute != CanvasBackingRoute.AHB) {
            throw IllegalStateException(
                "submitFrame is only supported on the 'ahb' route on Android."
            )
        }
        val buffer = hardwareBuffer
            ?: throw IllegalStateException("CanvasSurface has no AHardwareBuffer.")

        val expected = pixelWidth * pixelHeight * 4
        val available = pixels.size
        if (available < expected) {
            throw IllegalArgumentException(
                "submitFrame: pixel buffer is $available bytes, expected $expected " +
                "(RGBA8 ${pixelWidth}x${pixelHeight})."
            )
        }
        val byteBuffer = pixels.getBuffer(false)
        if (!byteBuffer.isDirect) {
            // AHardwareBuffer_lock writes into a direct memory region; we read
            // src bytes via JNI from a direct ByteBuffer to keep it zero-extra-copy.
            throw IllegalStateException(
                "submitFrame expects a direct ByteBuffer-backed ArrayBuffer."
            )
        }

        NativeBridge.nWritePixelsAHB(buffer, byteBuffer, pixelWidth, pixelHeight)
        publishCurrentHandle()
    }

    override fun resize(width: Double, height: Double) {
        val newWidth = width.toInt().coerceAtLeast(1)
        val newHeight = height.toInt().coerceAtLeast(1)

        val previousBuffer = hardwareBuffer
        val nextBuffer = if (storedRoute == CanvasBackingRoute.AHB) {
            createHardwareBuffer(newWidth, newHeight)
        } else {
            previousBuffer
        }

        pixelWidth = newWidth
        pixelHeight = newHeight
        hardwareBuffer = nextBuffer
        NativeBridge.nResize(surfaceId, newWidth, newHeight)
        publishCurrentHandle()

        if (nextBuffer !== previousBuffer) {
            previousBuffer?.close()
        }
    }

    override fun dispatchInput(phase: PointerPhase, uvX: Double, uvY: Double) {
        val phaseId = when (phase) {
            PointerPhase.DOWN -> CIV_PHASE_DOWN
            PointerPhase.MOVE -> CIV_PHASE_MOVE
            PointerPhase.UP   -> CIV_PHASE_UP
        }
        NativeBridge.nDispatchInput(surfaceId, phaseId, uvX.toFloat(), uvY.toFloat())
    }

    override fun dispose() {
        if (!disposed.compareAndSet(false, true)) return
        NativeBridge.nDispose(surfaceId)
        hardwareBuffer?.close()
        hardwareBuffer = null
    }

    private fun publishCurrentHandle() {
        when (storedRoute) {
            CanvasBackingRoute.AHB -> hardwareBuffer?.let {
                NativeBridge.nSubmitFrameAHB(surfaceId, pixelWidth, pixelHeight, isSRGB, it)
            }
            CanvasBackingRoute.SURFACE_TEXTURE ->
                NativeBridge.nSubmitFrameSurfaceTexture(
                    surfaceId, pixelWidth, pixelHeight, isSRGB, surfaceTextureGLId
                )
        }
    }

    private companion object {
        // Must match CIVRoute / CIVPhase values in cpp/CanvasInViroCBridge.h.
        const val CIV_ROUTE_AHB             = 0
        const val CIV_ROUTE_SURFACE_TEXTURE = 1
        const val CIV_PHASE_DOWN = 0
        const val CIV_PHASE_MOVE = 1
        const val CIV_PHASE_UP   = 2

        fun createHardwareBuffer(width: Int, height: Int): HardwareBuffer {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
                throw IllegalStateException("AHardwareBuffer surfaces require Android API 26 or newer.")
            }
            return HardwareBuffer.create(
                width, height, HardwareBuffer.RGBA_8888, 1,
                HardwareBuffer.USAGE_GPU_SAMPLED_IMAGE
                    or HardwareBuffer.USAGE_GPU_COLOR_OUTPUT
                    or HardwareBuffer.USAGE_CPU_WRITE_OFTEN
            )
        }
    }
}
