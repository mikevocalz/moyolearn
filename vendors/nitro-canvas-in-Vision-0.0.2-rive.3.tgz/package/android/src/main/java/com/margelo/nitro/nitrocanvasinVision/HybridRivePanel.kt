package com.margelo.nitro.nitrocanvasinVision

import android.os.Handler
import android.os.Looper
import android.os.Parcel
import android.view.Surface
import app.rive.runtime.kotlin.core.Artboard
import app.rive.runtime.kotlin.core.File as RiveFile
import app.rive.runtime.kotlin.core.Fit
import app.rive.runtime.kotlin.core.StateMachineInstance
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/** Owns the Rive file; the renderer holds an additional reference until its worker retires. */
@androidx.annotation.Keep
@com.facebook.proguard.annotations.DoNotStrip
internal class HybridRivePanel(
    private val surfaceId: Int,
    private val file: RiveFile,
    artboardName: String?,
    stateMachineName: String?,
    fit: RiveFit,
) : HybridRivePanelSpec(), CanvasSourceSurfaces.Listener {
    private val disposed = AtomicBoolean(false)
    private val active = AtomicBoolean(true)
    private var pointerPressed = false // guarded by file.lock
    private val frames = AtomicLong(0)
    private val main = Handler(Looper.getMainLooper())
    private val artboard: Artboard = if (artboardName == null) file.firstArtboard else file.artboard(artboardName)
    private val machine: StateMachineInstance? = when {
        stateMachineName != null -> artboard.stateMachine(stateMachineName)
        artboard.stateMachineCount > 0 -> artboard.stateMachine(0)
        else -> null
    }
    private val viewModel = if (file.viewModelCount > 0) {
        file.defaultViewModelForArtboard(artboard).createDefaultInstance().also {
            if (machine != null) machine.viewModelInstance = it else artboard.viewModelInstance = it
        }
    } else null
    private data class NumberObserver(val callback: (Double) -> Unit, var last: Double)
    private val numberObservers = mutableMapOf<String, NumberObserver>()
    private val renderFit = when (fit) {
        RiveFit.CONTAIN -> Fit.CONTAIN
        RiveFit.COVER -> Fit.COVER
        RiveFit.FILL -> Fit.FILL
    }
    // Accessed only on the main looper.
    private var renderer: RiveSurfaceRenderer? = null
    @Volatile private var attached = false
    @Volatile private var failure: String? = null

    override val artboardWidth = artboard.width.toDouble()
    override val artboardHeight = artboard.height.toDouble()
    override val surfaceAttached: Boolean get() = attached
    override val renderedFrames: Double get() = frames.get().toDouble()
    override val error: String? get() = failure

    init { CanvasSourceSurfaces.subscribe(surfaceId, this) }

    override fun onSurfaceChanged(surface: Surface?, width: Int, height: Int) {
        if (disposed.get()) return
        // Take an independent native reference while Viro's offer is still valid.
        // Rive must never release Viro's Java Surface wrapper.
        val borrowedCopy = try { surface?.let(::copySurface) } catch (error: RuntimeException) {
            failure = "Cannot acquire Rive Surface: ${error.message}"
            null
        }
        main.post {
            renderer?.delete()
            renderer = null
            attached = false
            if (disposed.get() || borrowedCopy == null) {
                borrowedCopy?.release()
                return@post
            }
            var next: RiveSurfaceRenderer? = null
            try {
                next = RiveSurfaceRenderer(file, artboard, machine, renderFit, borrowedCopy, active, frames, ::notifyChanges) {
                    failure = it.message ?: it.javaClass.simpleName
                }
                next.make()
                renderer = next
                next.attach()
                attached = true
                failure = null
                if (!active.get()) next.pause()
            } catch (error: RuntimeException) {
                failure = "Cannot attach Rive renderer: ${error.message}"
                if (next != null && next.hasCppObject) next.delete() else {
                    next?.releaseUnmade()
                    if (next == null) borrowedCopy.release()
                }
                renderer = null
            }
        }
    }

    override fun pointer(phase: RivePointerPhase, x: Double, y: Double) {
        require(x.isFinite() && y.isFinite()) { "Pointer coordinates must be finite" }
        change {
            if (!active.get()) return@change
            val sm = machine ?: return@change
            pointerPressed = phase == RivePointerPhase.DOWN || (pointerPressed && phase == RivePointerPhase.MOVE)
            when (phase) {
                RivePointerPhase.DOWN -> sm.pointerDown(0, x.toFloat(), y.toFloat())
                RivePointerPhase.MOVE -> sm.pointerMove(0, x.toFloat(), y.toFloat())
                RivePointerPhase.UP -> sm.pointerUp(0, x.toFloat(), y.toFloat())
                // Exit first so cancellation cannot activate a button on release.
                RivePointerPhase.CANCEL -> {
                    sm.pointerExit(0, x.toFloat(), y.toFloat())
                    sm.pointerUp(0, -Float.MAX_VALUE, -Float.MAX_VALUE)
                }
            }
        }
    }

    override fun setBoolean(name: String, value: Boolean) = change {
        requireNotNull(viewModel) { "No Rive view model" }.getBooleanProperty(name).value = value
    }
    override fun setNumber(name: String, value: Double) = change {
        require(value.isFinite()) { "Input value must be finite" }
        requireNotNull(viewModel) { "No Rive view model" }.getNumberProperty(name).value = value.toFloat()
    }
    override fun fireTrigger(name: String) = change {
        requireNotNull(viewModel) { "No Rive view model" }.getTriggerProperty(name).trigger()
    }

    override fun setString(name: String, value: String) = change {
        requireNotNull(viewModel) { "No Rive view model" }.getStringProperty(name).value = value
    }

    private fun <T> read(block: () -> T): T = synchronized(file.lock) {
        check(!disposed.get()) { "Rive panel is disposed" }
        block()
    }

    override fun getNumber(name: String): Double = read {
        requireNotNull(viewModel) { "No Rive view model" }.getNumberProperty(name).value.toDouble()
    }
    override fun getBoolean(name: String): Boolean = read {
        requireNotNull(viewModel) { "No Rive view model" }.getBooleanProperty(name).value
    }
    override fun getString(name: String): String = read {
        requireNotNull(viewModel) { "No Rive view model" }.getStringProperty(name).value
    }
    override fun observeNumber(name: String, callback: ((Double) -> Unit)?) {
        read {
            if (callback == null) numberObservers.remove(name)
            else numberObservers[name] = NumberObserver(callback, getNumber(name))
        }
    }

    // Invoked after advance, outside renderer/file locks. Nitro dispatches callbacks to JS.
    private fun notifyChanges() {
        val pending = synchronized(file.lock) {
            if (disposed.get()) return
            numberObservers.mapNotNull { (name, observer) ->
                val next = getNumber(name)
                if (next == observer.last) null else {
                    observer.last = next
                    observer.callback to next
                }
            }
        }
        for ((callback, value) in pending) if (!disposed.get()) callback(value)
    }

    private fun change(block: () -> Unit) {
        synchronized(file.lock) {
            check(!disposed.get()) { "Rive panel is disposed" }
            block()
        }
        main.post { if (!disposed.get()) renderer?.wake() }
    }

    override fun setActive(active: Boolean) {
        if (disposed.get()) return
        this.active.set(active)
        if (!active) synchronized(file.lock) {
            if (!disposed.get() && pointerPressed) {
                machine?.pointerExit(0, -Float.MAX_VALUE, -Float.MAX_VALUE)
                machine?.pointerUp(0, -Float.MAX_VALUE, -Float.MAX_VALUE)
                pointerPressed = false
            }
        }
        main.post {
            if (!disposed.get()) {
                if (this.active.get()) renderer?.wake() else renderer?.pause()
            }
        }
    }

    override fun dispose() {
        if (!disposed.compareAndSet(false, true)) return
        active.set(false)
        CanvasSourceSurfaces.unsubscribe(surfaceId, this)
        main.post {
            renderer?.delete()
            renderer = null
            attached = false
            synchronized(file.lock) { numberObservers.clear(); file.release() }
        }
    }

    private fun copySurface(surface: Surface): Surface {
        val parcel = Parcel.obtain()
        try {
            surface.writeToParcel(parcel, 0)
            parcel.setDataPosition(0)
            return Surface.CREATOR.createFromParcel(parcel)
        } finally { parcel.recycle() }
    }
}
