package com.margelo.nitro.nitrocanvasinVision

import android.hardware.HardwareBuffer
import android.os.Build

// Picks Route B when available (HardwareBuffer + GPU usage flags), falls
// back to Route A. The producer owns the SurfaceTexture under Route A.
internal class HybridCanvasSurfaceFactory : HybridCanvasSurfaceFactorySpec() {

    override fun create(
        width: Double, height: Double, scale: Double,
        sRGB: Boolean, androidRoute: CanvasBackingRoute
    ): HybridCanvasSurfaceSpec {
        val pixelWidth  = (width  * scale).toInt().coerceAtLeast(1)
        val pixelHeight = (height * scale).toInt().coerceAtLeast(1)

        if (androidRoute == CanvasBackingRoute.AHB
            && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val hb = try {
                HardwareBuffer.create(
                    pixelWidth, pixelHeight, HardwareBuffer.RGBA_8888, 1,
                    HardwareBuffer.USAGE_GPU_SAMPLED_IMAGE or HardwareBuffer.USAGE_GPU_COLOR_OUTPUT
                )
            } catch (e: Throwable) {
                null
            }
            if (hb != null) {
                return HybridCanvasSurface(
                    pixelWidth = pixelWidth,
                    pixelHeight = pixelHeight,
                    isSRGB = sRGB,
                    storedRoute = CanvasBackingRoute.AHB,
                    hardwareBuffer = hb,
                    surfaceTextureGLId = 0
                )
            }
        }

        return HybridCanvasSurface(
            pixelWidth = pixelWidth,
            pixelHeight = pixelHeight,
            isSRGB = sRGB,
            storedRoute = CanvasBackingRoute.SURFACE_TEXTURE,
            hardwareBuffer = null,
            surfaceTextureGLId = 0
        )
    }
}
