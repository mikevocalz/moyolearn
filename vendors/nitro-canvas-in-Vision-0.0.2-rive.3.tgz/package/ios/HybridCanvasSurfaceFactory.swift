import Foundation
import IOSurface
import NitroModules

class HybridCanvasSurfaceFactory: HybridCanvasSurfaceFactorySpec {
    func create(width: Double, height: Double, scale: Double,
                sRGB: Bool, androidRoute: CanvasBackingRoute) throws -> any HybridCanvasSurfaceSpec {
        let pixelWidth  = max(1, Int(width  * scale))
        let pixelHeight = max(1, Int(height * scale))

        let bytesPerElement = 4
        let bytesPerRow = IOSurface.minimumRowBytes(forWidth: pixelWidth,
                                                    bytesPerElement: bytesPerElement)
        let props: [IOSurfacePropertyKey: Any] = [
            .width:           pixelWidth,
            .height:          pixelHeight,
            .bytesPerElement: bytesPerElement,
            .bytesPerRow:     bytesPerRow,
            .pixelFormat:     Int(kCVPixelFormatType_32BGRA),
        ]
        guard let iosurface = IOSurface(properties: props) else {
            throw NSError(domain: "nitro-canvas-in-Vision", code: -1, userInfo: [
                NSLocalizedDescriptionKey: "Failed to allocate IOSurface \(pixelWidth)x\(pixelHeight)"
            ])
        }

        return HybridCanvasSurface(width: pixelWidth, height: pixelHeight,
                                   sRGB: sRGB, iosurface: iosurface,
                                   route: androidRoute)
    }
}
