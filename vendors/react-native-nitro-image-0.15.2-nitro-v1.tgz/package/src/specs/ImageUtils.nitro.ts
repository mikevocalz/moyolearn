import { Android, Apple, type HybridObject } from 'react-native-nitro-modules'

@Apple({ language: 'swift', implementation: { className: 'HybridImageUtils' } })
@Android({ language: 'kotlin', implementation: { className: 'HybridImageUtils' } })
export declare class ImageUtils extends HybridObject {
  constructor()

  /**
   * Returns `true` when the host platform supports loading Images
   * in `HEIC` format.
   */
  readonly supportsHeicLoading: boolean
  /**
   * Returns `true` when the host platform supports writing Images
   * in `HEIC` format.
   */
  readonly supportsHeicWriting: boolean

  /**
   * Converts the given ThumbHash {@linkcode ArrayBuffer} to a `string`.
   */
  thumbHashToBase64String(thumbhash: ArrayBuffer): string
  /**
   * Converts the given ThumbHash `string` to an {@linkcode ArrayBuffer}.
   */
  thumbhashFromBase64String(thumbhashBase64: string): ArrayBuffer
}

export * from '#nitro/ImageUtils'
