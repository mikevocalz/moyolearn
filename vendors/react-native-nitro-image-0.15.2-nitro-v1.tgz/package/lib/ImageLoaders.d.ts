import 'react-native-nitro-modules';
import { ImageLoaderFactory } from './specs/ImageLoaderFactory.nitro';
/**
 * A factory for creating `ImageLoader` instances.
 */
export declare const ImageLoaders: ImageLoaderFactory;
