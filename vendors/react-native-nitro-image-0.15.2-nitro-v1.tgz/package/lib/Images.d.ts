import 'react-native-nitro-modules';
import { ImageFactory } from './specs/ImageFactory.nitro';
/**
 * A factory for loading and creating `Image` instances.
 */
export declare const Images: ImageFactory;
