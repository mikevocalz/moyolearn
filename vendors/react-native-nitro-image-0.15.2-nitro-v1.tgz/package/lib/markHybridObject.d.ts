import { type AsyncImageSource } from './AsyncImageSource';
import type { Image } from './specs/Image.nitro';
import type { ImageLoader } from './specs/ImageLoader.nitro';
export declare function markHybridObject(object: Image | ImageLoader, source: AsyncImageSource): typeof object;
