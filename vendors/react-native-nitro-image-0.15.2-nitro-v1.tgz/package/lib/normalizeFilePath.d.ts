export declare function normalizeFilePath(filePath: string): string;
