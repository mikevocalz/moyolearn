import type { HybridObject } from 'react-native-nitro-modules';
import type { OptionalAsyncOptions } from './OptionalWebLoader';
import type { EncodedImageData, Image, RawPixelData } from './specs/Image.nitro';
import type { ImageLoader } from './specs/ImageLoader.nitro';
export type RequireType = number;
export type AsyncImageSource = Image | ImageLoader | {
    filePath: string;
} | {
    rawPixelData: RawPixelData;
} | {
    encodedImageData: EncodedImageData;
} | {
    resource: string;
} | {
    symbolName: string;
} | {
    url: string;
    options?: OptionalAsyncOptions;
} | RequireType;
export declare function isHybridObject<T>(obj: T): obj is HybridObject;
export declare function isHybridImage<T>(obj: T): obj is Image;
export declare function isHybridImageLoader<T>(obj: T): obj is ImageLoader;
