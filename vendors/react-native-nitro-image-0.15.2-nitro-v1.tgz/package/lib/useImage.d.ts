import { type AsyncImageSource } from './AsyncImageSource';
import type { Image } from './specs/Image.nitro';
type Result = {
    image: undefined;
    error: undefined;
} | {
    image: Image;
    error: undefined;
} | {
    image: undefined;
    error: Error;
};
/**
 * A hook to asynchronously load an image from the
 * given {@linkcode AsyncImageSource} into memory.
 * @example
 * ```ts
 * const { image, error } = useImage({ filePath: '/tmp/image.jpg' })
 * ```
 */
export declare function useImage(source: AsyncImageSource): Result;
export {};
