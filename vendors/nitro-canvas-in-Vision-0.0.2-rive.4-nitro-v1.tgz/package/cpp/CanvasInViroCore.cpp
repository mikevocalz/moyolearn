#include "CanvasInViroCore.h"
#include <cmath>

namespace nitrocanvasinVision {

namespace {

// Registry holds weak_ptrs so lifetime is owned by the HybridObject, not the map.
std::mutex &registryMutex() {
    static std::mutex m;
    return m;
}

std::unordered_map<int, std::weak_ptr<CanvasInViroCore>> &registry() {
    static std::unordered_map<int, std::weak_ptr<CanvasInViroCore>> r;
    return r;
}

int nextId() {
    static std::atomic<int> counter {1};
    return counter.fetch_add(1, std::memory_order_relaxed);
}

} // namespace

std::shared_ptr<CanvasInViroCore> CanvasInViroCore::allocate(int width, int height,
                                                              bool sRGB, BackingRoute route) {
    if (width <= 0 || height <= 0) return nullptr;
    int id = nextId();
    auto core = std::shared_ptr<CanvasInViroCore>(
        new CanvasInViroCore(id, width, height, sRGB, route));
    std::lock_guard<std::mutex> lock(registryMutex());
    registry().emplace(id, core);
    return core;
}

std::shared_ptr<CanvasInViroCore> CanvasInViroCore::lookup(int id) {
    std::shared_ptr<CanvasInViroCore> core;
    {
        std::lock_guard<std::mutex> lock(registryMutex());
        auto it = registry().find(id);
        if (it == registry().end()) return nullptr;
        core = it->second.lock();
    }
    // Release the registry lock before potentially dropping the last owner.
    return core && !core->isDisposed() ? core : nullptr;
}

CanvasInViroCore::CanvasInViroCore(int id, int width, int height, bool sRGB, BackingRoute route)
    : _id(id), _width(width), _height(height), _sRGB(sRGB), _route(route) {}

CanvasInViroCore::~CanvasInViroCore() {
    dispose();
}

void CanvasInViroCore::dispose() {
    bool wasAlive = !_disposed.exchange(true, std::memory_order_acq_rel);
    if (!wasAlive) return;

    {
        std::lock_guard<std::mutex> lock(registryMutex());
        registry().erase(_id);
    }
    {
        std::lock_guard<std::mutex> lock(_payloadMutex);
        _payload = {};
    }
    {
        std::lock_guard<std::mutex> lock(_inputMutex);
        _inputQueue.clear();
    }
}

void CanvasInViroCore::submitFrame(const SharedHandlePayload &payload) {
    std::lock_guard<std::mutex> lock(_payloadMutex);
    if (_disposed.load(std::memory_order_acquire)) return;
    if (payload.width != width() || payload.height != height()) return;
    _payload = payload;
    _frameSeq.fetch_add(1, std::memory_order_release);
}

void CanvasInViroCore::markDirty() {
    std::lock_guard<std::mutex> lock(_payloadMutex);
    if (_disposed.load(std::memory_order_acquire)) return;
    if (_payload.width != width() || _payload.height != height()) return;
    _frameSeq.fetch_add(1, std::memory_order_release);
}

std::optional<SharedHandlePayload> CanvasInViroCore::consumeIfDirty() {
    std::lock_guard<std::mutex> lock(_payloadMutex);
    if (_disposed.load(std::memory_order_acquire)) return std::nullopt;
    const uint64_t frame = _frameSeq.load(std::memory_order_acquire);
    if (frame == _consumedSeq.load(std::memory_order_relaxed)) return std::nullopt;
    _consumedSeq.store(frame, std::memory_order_release);
    // A resize invalidates the old handle until the producer publishes its
    // replacement. Never pair old storage with new dimensions.
    if (_payload.width != width() || _payload.height != height()) return std::nullopt;
    return _payload;
}

void CanvasInViroCore::resize(int width, int height) {
    std::lock_guard<std::mutex> lock(_payloadMutex);
    if (_disposed.load(std::memory_order_acquire) || width <= 0 || height <= 0) return;
    if (width == this->width() && height == this->height()) return;
    _width.store(width, std::memory_order_relaxed);
    _height.store(height, std::memory_order_relaxed);
    _payload = {};
    _frameSeq.fetch_add(1, std::memory_order_release);
}

void CanvasInViroCore::dispatchInput(PointerPhase phase, float uvX, float uvY) {
    if (!std::isfinite(uvX) || !std::isfinite(uvY)) return;
    if (phase != PointerPhase::Down && phase != PointerPhase::Move && phase != PointerPhase::Up) return;
    std::lock_guard<std::mutex> lock(_inputMutex);
    if (_disposed.load(std::memory_order_acquire)) return;
    InputEvent ev { phase, uvX, uvY, _inputSeq.fetch_add(1, std::memory_order_relaxed) };
    _inputQueue.push_back(ev);
}

std::vector<InputEvent> CanvasInViroCore::drainInputs() {
    std::vector<InputEvent> out;
    std::lock_guard<std::mutex> lock(_inputMutex);
    if (_disposed.load(std::memory_order_acquire)) return out;
    out.swap(_inputQueue);
    return out;
}

} // namespace nitrocanvasinVision
