import Foundation
import CoreVideo
import IOSurface
import NitroModules
import NitroCanvasInVisionCBridge

final class HybridCanvasSurface: HybridCanvasSurfaceSpec {
    private let surfaceId: Int32
    private let storedRoute: CanvasBackingRoute
    private var pixelWidth: Int
    private var pixelHeight: Int
    private let isSRGB: Bool
    private var disposed = false

    // Strong ref so the IOSurface outlives any producer wrapper.
    private var liveIOSurface: IOSurfaceRef

    init(width: Int, height: Int, sRGB: Bool, iosurface: IOSurfaceRef,
         route: CanvasBackingRoute) throws {
        self.pixelWidth    = width
        self.pixelHeight   = height
        self.isSRGB        = sRGB
        self.liveIOSurface = iosurface
        self.storedRoute   = route

        let civRoute: CIVRoute = (route == .surfaceTexture) ? CIV_ROUTE_SURFACE_TEXTURE
                                                            : CIV_ROUTE_AHB
        self.surfaceId = Int32(CIVAllocate(Int32(width), Int32(height), sRGB, civRoute))

        try super.init()
        publishCurrentHandle()
    }

    deinit { disposeSurface() }

    var id: Double { Double(surfaceId) }
    var width: Double { Double(pixelWidth) }
    var height: Double { Double(pixelHeight) }
    var route: CanvasBackingRoute { storedRoute }

    func markDirty() throws {
        try requireLive()
        publishCurrentHandle()
    }

    func getAHardwareBufferPointer() throws -> Double {
        throw NSError(domain: "nitro-canvas-in-Vision", code: -5,
                      userInfo: [NSLocalizedDescriptionKey:
                          "getAHardwareBufferPointer is Android-only."])
    }

    func getIOSurfaceID() throws -> Double {
        try requireLive()
        // Stable for the lifetime of the IOSurface; the peer (Dawn) recovers
        // an IOSurfaceRef via IOSurfaceLookup(id).
        return Double(IOSurfaceGetID(liveIOSurface))
    }

    func submitFrame(pixels: ArrayBuffer) throws {
        try requireLive()
        let expected = pixelWidth * pixelHeight * 4
        guard Int(pixels.size) >= expected else {
            throw NSError(domain: "nitro-canvas-in-Vision", code: -3,
                          userInfo: [NSLocalizedDescriptionKey:
                              "submitFrame: pixel buffer is \(pixels.size) bytes, expected \(expected) (RGBA8 \(pixelWidth)x\(pixelHeight))."])
        }

        let surface = liveIOSurface
        guard IOSurfaceLock(surface, [], nil) == 0 else {
            throw NSError(domain: "nitro-canvas-in-Vision", code: -7,
                          userInfo: [NSLocalizedDescriptionKey: "Cannot lock canvas IOSurface for writing."])
        }
        defer { IOSurfaceUnlock(surface, [], nil) }

        // IOSurface here is kCVPixelFormatType_32BGRA; JS submits RGBA8. Swizzle on
        // the way in. Per-row to honor IOSurface's bytesPerRow alignment.
        let bytesPerRow = IOSurfaceGetBytesPerRow(surface)
        let dstBase = IOSurfaceGetBaseAddress(surface).assumingMemoryBound(to: UInt8.self)
        // Nitro V1: ArrayBuffer.data is optional (nil for an empty buffer).
        guard let src = pixels.data else {
            throw NSError(domain: "nitro-canvas-in-Vision", code: -3,
                          userInfo: [NSLocalizedDescriptionKey: "submitFrame: pixel buffer has no backing memory."])
        }
        let rowBytes = pixelWidth * 4
        for y in 0..<pixelHeight {
            let dstRow = dstBase.advanced(by: y * bytesPerRow)
            let srcRow = src.advanced(by: y * rowBytes)
            for x in 0..<pixelWidth {
                let s = srcRow.advanced(by: x * 4)
                let d = dstRow.advanced(by: x * 4)
                d[0] = s[2]
                d[1] = s[1]
                d[2] = s[0]
                d[3] = s[3]
            }
        }

        publishCurrentHandle()
    }

    func resize(width: Double, height: Double) throws {
        try requireLive()
        guard width.isFinite, height.isFinite,
              width > 0, height > 0, width <= 16384, height <= 16384 else {
            throw NSError(domain: "nitro-canvas-in-Vision", code: -6,
                          userInfo: [NSLocalizedDescriptionKey: "Canvas dimensions must be finite, positive, and at most 16384 pixels."])
        }
        let newW = max(1, Int(width))
        let newH = max(1, Int(height))
        let bpe = 4
        let bpr = IOSurfaceAlignProperty(kIOSurfaceBytesPerRow, newW * bpe)
        let props: [CFString: Any] = [
            kIOSurfaceWidth: newW, kIOSurfaceHeight: newH,
            kIOSurfaceBytesPerElement: bpe, kIOSurfaceBytesPerRow: bpr,
            kIOSurfacePixelFormat: Int(kCVPixelFormatType_32BGRA),
        ]
        guard let newSurface = IOSurfaceCreate(props as CFDictionary) else {
            throw NSError(domain: "nitro-canvas-in-Vision", code: -2)
        }
        liveIOSurface = newSurface
        pixelWidth = newW
        pixelHeight = newH
        CIVResize(surfaceId, Int32(newW), Int32(newH))
        publishCurrentHandle()
    }

    func dispatchInput(phase: PointerPhase, uvX: Double, uvY: Double) throws {
        try requireLive()
        let civPhase: CIVPhase
        switch phase {
        case .down: civPhase = CIV_PHASE_DOWN
        case .move: civPhase = CIV_PHASE_MOVE
        case .up:   civPhase = CIV_PHASE_UP
        }
        CIVDispatchInput(surfaceId, civPhase, Float(uvX), Float(uvY))
    }

    func dispose() {
        disposeSurface()
    }

    private func requireLive() throws {
        guard !disposed else {
            throw NSError(domain: "nitro-canvas-in-Vision", code: -4,
                          userInfo: [NSLocalizedDescriptionKey: "Canvas surface is disposed."])
        }
    }

    private func disposeSurface() {
        if disposed { return }
        disposed = true
        CIVDispose(surfaceId)
    }

    private func publishCurrentHandle() {
        let addr = UInt(bitPattern: Unmanaged.passUnretained(liveIOSurface).toOpaque())
        CIVSubmitFrame(surfaceId,
                       Int32(pixelWidth), Int32(pixelHeight), isSRGB,
                       UInt(addr),     // iosurface
                       UInt(0),        // ahardwareBuffer
                       UInt32(0))      // surfaceTextureGLId
    }
}
