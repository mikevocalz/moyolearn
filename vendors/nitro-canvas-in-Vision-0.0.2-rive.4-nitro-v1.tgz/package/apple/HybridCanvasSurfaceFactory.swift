import Foundation
import CoreVideo
import IOSurface
import NitroModules
import NitroCanvasInVisionCBridge

final class HybridCanvasSurfaceFactory: HybridCanvasSurfaceFactorySpec {
    func create(width: Double, height: Double, scale: Double,
                sRGB: Bool, androidRoute: CanvasBackingRoute) throws -> any HybridCanvasSurfaceSpec {
        guard width.isFinite, height.isFinite, scale.isFinite,
              width > 0, height > 0, scale > 0,
              (width * scale).isFinite, (height * scale).isFinite,
              width * scale <= 16384, height * scale <= 16384 else {
            throw NSError(domain: "nitro-canvas-in-Vision", code: -6,
                          userInfo: [NSLocalizedDescriptionKey: "Canvas dimensions must be finite, positive, and at most 16384 pixels after scaling."])
        }
        let pixelWidth  = max(1, Int(width  * scale))
        let pixelHeight = max(1, Int(height * scale))

        let bytesPerElement = 4
        let bytesPerRow = IOSurfaceAlignProperty(kIOSurfaceBytesPerRow, pixelWidth * bytesPerElement)
        let props: [CFString: Any] = [
            kIOSurfaceWidth:           pixelWidth,
            kIOSurfaceHeight:          pixelHeight,
            kIOSurfaceBytesPerElement: bytesPerElement,
            kIOSurfaceBytesPerRow:     bytesPerRow,
            kIOSurfacePixelFormat:     Int(kCVPixelFormatType_32BGRA),
        ]
        guard let iosurface = IOSurfaceCreate(props as CFDictionary) else {
            throw NSError(domain: "nitro-canvas-in-Vision", code: -1, userInfo: [
                NSLocalizedDescriptionKey: "Failed to allocate IOSurface \(pixelWidth)x\(pixelHeight)"
            ])
        }

        return try HybridCanvasSurface(width: pixelWidth, height: pixelHeight,
                                   sRGB: sRGB, iosurface: iosurface,
                                   route: androidRoute)
    }
}
