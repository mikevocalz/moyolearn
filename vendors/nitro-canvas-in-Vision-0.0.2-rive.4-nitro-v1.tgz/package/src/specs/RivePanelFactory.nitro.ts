import { Android, type HybridObject } from 'react-native-nitro-modules'
import type { RivePanel, RiveFit } from './RivePanel.nitro'

@Android({ language: 'kotlin', implementation: { className: 'HybridRivePanelFactory' } })
export declare class RivePanelFactory extends HybridObject {
  constructor()

  create(surfaceId: number, bytes: ArrayBuffer, artboard: string | undefined,
    stateMachine: string | undefined, fit: RiveFit): Promise<RivePanel>
}

export * from '#nitro/RivePanelFactory'
