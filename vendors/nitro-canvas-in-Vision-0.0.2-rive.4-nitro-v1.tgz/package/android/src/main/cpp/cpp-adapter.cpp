#include <jni.h>
#include <fbjni/fbjni.h>
#include <NitroCanvasInVision/private/NitroCanvasInVisionOnLoad.hpp>

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
  return facebook::jni::initialize(vm, []() {
    margelo::nitro::nitrocanvasinVision::registerAllNatives();
  });
}
