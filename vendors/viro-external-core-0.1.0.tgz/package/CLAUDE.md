# CLAUDE — standing preferences

- Terse output. Code first.
- Zustand for shared/business state. Never `useState` for app state.
- Functional components only.
- Verified APIs only.
- Quality bar: FAANG / Linear / Vercel grade.
- Design and motion carry semantic weight.
- Performance is a feature.
