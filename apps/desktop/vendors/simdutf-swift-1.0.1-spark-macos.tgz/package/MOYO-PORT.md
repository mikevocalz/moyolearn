# simdutf-swift 1.0.1 as a CocoaPods pod

Nitro v1 (`react-native-nitro-modules` 1.0.0-alpha.nightly.100.g107f6fc66597)
imports `SimdUTF` from margelo/simdutf-swift through SwiftPM. Moyo Learn for
macOS builds with Legend Spark 0.0.2 (React Native macOS 0.83, CocoaPods), and
CocoaPods cannot resolve a SwiftPM dependency, so this package wraps the same
sources in a pod. Moyo's Spark port of Nitro declares `s.dependency "SimdUTF"`.

- simdutf-swift tag `1.0.1`, commit `4f98b5b16c8b1d9c7d77d88395c2a50b74be0607`
- simdutf submodule tag `v9.2.1`, commit `dc3f7a8fa291f2ce793c7b0ddd458f4e67542f14`
- Copied unchanged: `LICENSE`, `NOTICE`, `Sources/`, and simdutf's
  `include/`, `src/`, `LICENSE-MIT`, `LICENSE-APACHE`. `SHA256SUMS` lists every
  copied file.
- Added: `package.json`, `react-native.config.js`, `SimdUTF.podspec`,
  `cocoapods/CSimdUTF/module.modulemap` and this file.
- Not copied: `Package.swift` (React Native 0.83 builds through the podspec),
  tests, scripts and CI.
