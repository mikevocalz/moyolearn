// CocoaPods autolinking discovers SimdUTF.podspec through this package; it has no Android code.
module.exports = {
  dependency: {
    platforms: {
      ios: {},
      android: null,
    },
  },
}
