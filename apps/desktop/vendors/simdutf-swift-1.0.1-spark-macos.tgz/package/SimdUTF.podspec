require "json"

package = JSON.parse(File.read(File.join(__dir__, "package.json")))

# margelo/simdutf-swift as a pod. Nitro v1 depends on it through SwiftPM
# (traits UTF8, UTF16, ASCII); React Native macOS 0.83 builds with CocoaPods,
# so Moyo's Legend Spark port of react-native-nitro-modules depends on this pod.
# The two SwiftPM targets map to the SimdUTF Swift module and the CSimdUTF clang
# module (cocoapods/CSimdUTF/module.modulemap). See MOYO-PORT.md.
Pod::Spec.new do |s|
  s.name = "SimdUTF"
  s.version = package["version"]
  s.summary = package["description"]
  s.homepage = package["homepage"]
  s.license = { :type => "MIT", :file => "LICENSE" }
  s.authors = package["author"]
  s.source = { :git => "https://github.com/margelo/simdutf-swift.git", :tag => s.version.to_s }
  s.osx.deployment_target = "13.0"

  s.source_files = [
    "Sources/SimdUTF/*.swift",
    "Sources/CSimdUTF/*.cpp",
  ]
  # Headers reach the compiler through HEADER_SEARCH_PATHS only, so CocoaPods
  # does not link them into Pods/Headers outside the CSimdUTF module map.
  s.preserve_paths = [
    "Sources/CSimdUTF/**/*.h",
    "simdutf/**/*",
    "cocoapods/**/*",
  ]
  s.swift_version = "6.0"

  # The traits Nitro v1 enables (Package.swift: traits: ["UTF8", "UTF16", "ASCII"]),
  # as Swift compilation conditions and as simdutf-swift's C++ feature gates.
  traits = %w[UTF8 UTF16 ASCII]
  s.pod_target_xcconfig = {
    "CLANG_CXX_LANGUAGE_STANDARD" => "c++17",
    "DEFINES_MODULE" => "YES",
    "HEADER_SEARCH_PATHS" => [
      "cocoapods",
      "Sources/CSimdUTF/include",
      "simdutf/include",
      "simdutf/src",
    ].map { |dir| "\"${PODS_TARGET_SRCROOT}/#{dir}\"" }.join(" "),
    "GCC_PREPROCESSOR_DEFINITIONS" => traits.map { |trait| "SIMDUTF_SWIFT_ENABLE_#{trait}=1" }.join(" "),
    "SWIFT_ACTIVE_COMPILATION_CONDITIONS" => "$(inherited) #{traits.join(" ")}",
  }
end
