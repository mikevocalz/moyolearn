
#pragma once

#include <NitroModules/Dispatcher.hpp>

namespace margelo::nitro {

class UIThreadDispatcher : public Dispatcher {
public:
  void runSync(std::function<void()>&& function) override;
  bool isOnDispatcher() override;
  void runAsync(std::function<void()>&& function) override;
};

} // namespace margelo::nitro