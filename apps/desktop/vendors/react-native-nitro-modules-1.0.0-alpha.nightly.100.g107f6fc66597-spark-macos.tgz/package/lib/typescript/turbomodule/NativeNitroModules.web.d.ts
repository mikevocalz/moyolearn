export {};
//# sourceMappingURL=NativeNitroModules.web.d.ts.map