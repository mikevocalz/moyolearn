export {};
//# sourceMappingURL=NativeNitroModules.d.ts.map