import { type HostComponent } from 'react-native';
/** Shared attribute configuration for generated Nitro view props. */
export declare const NitroViewProp: {
    diff(previous: unknown, next: unknown): boolean;
    process(value: unknown): unknown;
};
/** Registers a native view with its generated Fabric attributes. */
export declare function getHostComponent<Props extends object>(name: string, validAttributes: Readonly<Record<string, typeof NitroViewProp>>): HostComponent<Props>;
//# sourceMappingURL=getHostComponent.d.ts.map