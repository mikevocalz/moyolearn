require "json"
require_relative "apple/cocoapods/nitro_cocoapods"

package = JSON.parse(File.read(File.join(__dir__, "package.json")))

# Legend Spark port: upstream v1 ships a metadata-only podspec and builds through
# SwiftPM, which needs React Native 0.88. React Native macOS 0.83 (Legend Spark
# 0.0.2) installs pods, so this podspec builds the same sources as Package.swift.
# See apple/cocoapods/nitro_cocoapods.rb and SPARK-MACOS.md.
Pod::Spec.new do |s|
  s.name = "NitroModules"
  s.version = package["version"]
  s.summary = package["description"]
  s.homepage = package["homepage"]
  s.license = package["license"]
  s.authors = package["author"]
  s.source = { :git => "https://github.com/margelo/nitro.git", :tag => "v#{s.version}" }
  # Only macOS is built and verified through this podspec. iOS, tvOS and
  # visionOS keep using upstream's SwiftPM path on React Native 0.88.
  s.osx.deployment_target = "13.0"

  NitroCocoaPods.configure_nitro_modules(s)

  s.dependency "React-jsi"
  s.dependency "React-callinvoker"
  install_modules_dependencies(s)
end
