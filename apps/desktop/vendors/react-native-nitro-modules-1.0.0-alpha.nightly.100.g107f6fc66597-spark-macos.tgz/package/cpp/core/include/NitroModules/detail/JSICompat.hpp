//
//  JSICompat.hpp
//  NitroModules
//
//  Moyo Learn port for Legend Spark (React Native macOS 0.83).
//  Nitro v1 targets React Native 0.88's JSI, which added `jsi::Array::push`,
//  `jsi::Runtime::createError` and `jsi::ArrayBuffer::tryGetMutableBuffer`.
//  React Native macOS 0.83 ships none of them. The helpers below use the JSI
//  member when the headers declare it and an equivalent that 0.83 supports
//  otherwise, so the same source builds on both.
//

#pragma once

#include <jsi/jsi.h>

#include <cstddef>
#include <initializer_list>
#include <memory>
#include <utility>

namespace margelo::nitro::detail {

namespace jsi = facebook::jsi;

template <typename Array>
concept JSIArrayHasPush = requires(Array& array, jsi::Runtime& runtime, const jsi::Value* values, size_t count) {
  array.push(runtime, values, count);
};

template <typename Runtime>
concept JSIRuntimeHasCreateError = requires(Runtime& runtime, jsi::String message) { runtime.createError(std::move(message)); };

template <typename ArrayBuffer>
concept JSIArrayBufferHasTryGetMutableBuffer = requires(ArrayBuffer& buffer, jsi::Runtime& runtime) {
  buffer.tryGetMutableBuffer(runtime);
};

/**
 * Whether `jsi::Array::push` exists. Without it, callers create the array at
 * its final size and fill it with `setValueAtIndex`. Calling the JS
 * `Array.prototype.push` instead would pass every element as a call argument,
 * which fails for large arrays.
 */
inline constexpr bool kJSIHasArrayPush = JSIArrayHasPush<jsi::Array>;

/**
 * Calls `jsi::Array::push`. Only instantiate it when `kJSIHasArrayPush` is
 * true; `Array` is a template parameter so the call is not checked otherwise.
 */
template <typename Array>
inline void jsiArrayPush(jsi::Runtime& runtime, Array& array, const jsi::Value* values, size_t count) {
  array.push(runtime, values, count);
}

template <typename Array>
inline void jsiArrayPush(jsi::Runtime& runtime, Array& array, std::initializer_list<jsi::Value> values) {
  array.push(runtime, values);
}

/** Creates a JS `Error` with the given message. Without `createError`, calls the global `Error` constructor. */
template <typename Runtime>
inline jsi::Value jsiCreateError(Runtime& runtime, jsi::String message) {
  if constexpr (JSIRuntimeHasCreateError<Runtime>) {
    return runtime.createError(std::move(message));
  } else {
    jsi::Function errorConstructor = runtime.global().getPropertyAsFunction(runtime, "Error");
    return errorConstructor.callAsConstructor(runtime, std::move(message));
  }
}

/**
 * Returns the native buffer backing a JS ArrayBuffer, or `nullptr`.
 * React Native 0.83's JSI cannot expose it, so callers always take their
 * borrowing or copying path there: `asOwning()` copies instead of aliasing
 * JS memory.
 */
template <typename ArrayBuffer>
inline std::shared_ptr<jsi::MutableBuffer> jsiTryGetMutableBuffer([[maybe_unused]] jsi::Runtime& runtime,
                                                                   [[maybe_unused]] ArrayBuffer& buffer) {
  if constexpr (JSIArrayBufferHasTryGetMutableBuffer<ArrayBuffer>) {
    return buffer.tryGetMutableBuffer(runtime);
  } else {
    return nullptr;
  }
}

} // namespace margelo::nitro::detail
