# react-native-nitro-modules 1.0.0-alpha.nightly.100.g107f6fc66597, Legend Spark macOS port

Moyo Learn for macOS runs on Legend Spark 0.0.2 (React Native macOS 0.83,
CocoaPods). Spark ships Nitro 0.37.0 with its own patch; Moyo pins Nitro v1
nightly.100 on every platform, so this is that nightly with the macOS parts of
Spark's patch carried over, plus what v1 needs to build without SwiftPM.

Upstream: `react-native-nitro-modules@1.0.0-alpha.nightly.100.g107f6fc66597`
(npm integrity in `package.json` `spark.upstreamIntegrity`).

## Changes

1. **AppKit views** (from Spark's 0.37.0 patch). `apple/views/HybridView.swift`
   declares `NitroPlatformView` as `UIView` or `NSView`, so `HybridView`
   compiles on macOS.
2. **Buildable podspec.** Upstream's podspec is metadata only. `NitroModules.podspec`
   builds the sources Package.swift builds, for macOS 13+, through
   `apple/cocoapods/nitro_cocoapods.rb`, which also gives nitrogen-generated
   libraries their pod settings (`NitroCocoaPods.add_nitrogen_module`).
   Spark's 0.37.0 patch moved the view template headers out of the public
   headers; here every header is private and reaches Swift only through the
   upstream module maps.
3. **React Native 0.83 JSI.** `cpp/core/include/NitroModules/detail/JSICompat.hpp`
   supplies `jsi::Array::push`, `jsi::Runtime::createError` and
   `jsi::ArrayBuffer::tryGetMutableBuffer` (added after 0.83). Each helper
   uses the JSI member when the headers have it, so the code is unchanged on 0.88.
4. **simdutf-swift.** Upstream resolves margelo/simdutf-swift 1.0.1 through
   SwiftPM. Here `NitroModules.podspec` depends on the `SimdUTF` pod from the
   `simdutf-swift` package (Moyo's CocoaPods packaging of that tag, a peer
   dependency of this port).
5. **package.json.** `react-native` peer range widened to `>=0.83.0`, a peer
   dependency on `simdutf-swift` 1.0.1, and the `spark` stamp Spark's
   native-patch preflight reads.

Not carried over from Spark's patch: the Windows adapter (`windows/`,
`NITRO_WINDOWS_API` exports, react-native.config.js Windows entry). Moyo's
desktop build is macOS only.

The `.patch` file next to the tarball in the app is the diff of all of the
above against upstream, except the `spark` stamp, which carries the patch's
SHA-256 as `spark.patchHash`.
