#import <TargetConditionals.h>
#if TARGET_OS_OSX
#import <React/RCTUIKit.h>
#else
#import <UIKit/UIKit.h>
#endif

NS_ASSUME_NONNULL_BEGIN

#if TARGET_OS_OSX
@interface ThreadedRuntimeSurfaceView : RCTUIView
#else
@interface ThreadedRuntimeSurfaceView : UIView
#endif

@property (nonatomic, copy) NSString *appName;
@property (nonatomic, copy) NSString *blockStatus;
@property (nonatomic, copy) NSString *componentName;
@property (nonatomic, copy) NSString *initialPropsJson;
@property (nonatomic, copy) NSString *mode;
@property (nonatomic, copy) NSString *runtimeName;
@property (nonatomic, copy) NSString *surfaceKey;

@end

NS_ASSUME_NONNULL_END
