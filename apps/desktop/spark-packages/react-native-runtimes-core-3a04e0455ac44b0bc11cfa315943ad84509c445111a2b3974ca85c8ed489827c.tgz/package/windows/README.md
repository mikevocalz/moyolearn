Windows native implementation lives in @legendapp/spark-desktop-host/windows/runtimes.inc.
