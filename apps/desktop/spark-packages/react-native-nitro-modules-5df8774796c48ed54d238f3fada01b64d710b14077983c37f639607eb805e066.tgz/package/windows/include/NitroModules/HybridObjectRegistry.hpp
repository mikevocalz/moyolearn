#include "../../../cpp/registry/HybridObjectRegistry.hpp"
