#include "../../../cpp/templates/InstanceMethod.hpp"
