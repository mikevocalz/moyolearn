#include "../../../cpp/views/ViewComponentDescriptor.hpp"
