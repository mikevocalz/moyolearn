#include "../../../cpp/templates/CountTrailingOptionals.hpp"
