#include "../../../cpp/prototype/HybridObjectPrototype.hpp"
