import type { NitroViewWrappedCallback } from './getHostComponent';
/**
 * Wrap the given {@linkcode func} in a Nitro callback.
 * - For older versions of react-native, this wraps the callback in a `{ f: T }` object.
 * - For newer versions of react-native, this just returns the function as-is.
 */
export declare function callback<T>(func: T): T extends (...args: any[]) => any ? NitroViewWrappedCallback<T> : T;
//# sourceMappingURL=callback.d.ts.map