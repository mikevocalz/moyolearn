// https://github.com/react-native-community/cli/blob/main/docs/dependencies.md

module.exports = {
  dependency: {
    platforms: {
      /**
       * @type {import('@react-native-community/cli-types').IOSDependencyParams}
       */
      ios: {},
      /**
       * @type {import('@react-native-community/cli-types').AndroidDependencyParams}
       */
      android: {},
    },
  },
}

module.exports.dependency ??= {}; module.exports.dependency.platforms ??= {};
module.exports.dependency.platforms.windows = {"sourceDir":"windows","solutionFile":"SparkNitro.sln","projects":[{"projectFile":"SparkNitro/SparkNitro.vcxproj","directDependency":true}]};
