#pragma once

#include <ReactCommon/CallInvoker.h>
#include <jsi/jsi.h>
#include <memory>
#ifdef OP_SQLITE_USE_LIBSQL
#include "libsql.h"
#include "libsql/OPLibsqlBridge.hpp"
#else
#ifdef __ANDROID__
#include "sqlite3.h"
#else
#include <sqlite3.h>
#endif
#endif
#include "OPThreadPool.hpp"
#include <string>
#include <utility>

namespace opsqlite {
namespace jsi = facebook::jsi;
namespace react = facebook::react;

class PreparedStatementHostObject : public jsi::HostObject {
public:
#ifdef OP_SQLITE_USE_LIBSQL
  PreparedStatementHostObject(DB const &db, libsql_stmt_t stmt,
                              std::shared_ptr<ThreadPool> thread_pool)
      : _db(db), _stmt(stmt), _thread_pool(thread_pool) {};
#else
  PreparedStatementHostObject(sqlite3 *db, sqlite3_stmt *stmt,
                              std::shared_ptr<ThreadPool> thread_pool)
      : _db(db), _stmt(stmt), _thread_pool(thread_pool) {};
#endif

  ~PreparedStatementHostObject() override;

  std::vector<jsi::PropNameID> getPropertyNames(jsi::Runtime &rt) override;

  jsi::Value get(jsi::Runtime &rt, const jsi::PropNameID &propNameID) override;

private:
#ifdef OP_SQLITE_USE_LIBSQL
  DB _db;
  libsql_stmt_t _stmt;
#else
  sqlite3 *_db;
  // This shouldn't be de-allocated until sqlite3_finalize is called on it
  sqlite3_stmt *_stmt;
#endif
  std::shared_ptr<ThreadPool> _thread_pool;
};

} // namespace opsqlite
