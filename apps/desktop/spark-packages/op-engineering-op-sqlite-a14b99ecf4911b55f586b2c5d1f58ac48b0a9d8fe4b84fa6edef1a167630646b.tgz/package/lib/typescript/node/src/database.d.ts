import type { BatchQueryResult, DB, FileLoadResult, PreparedStatement, QueryResult, RawQueryResult, Scalar, SQLBatchTuple, Transaction, UpdateHookOperation } from "./types";
export declare class NodeDatabase implements DB {
    private db;
    private dbPath;
    private updateHookCallback?;
    private commitHookCallback?;
    private rollbackHookCallback?;
    constructor(name: string, location?: string);
    private setupHooks;
    private convertParams;
    private convertRows;
    executeSync(query: string, params?: Scalar[]): QueryResult;
    execute(query: string, params?: Scalar[]): Promise<QueryResult>;
    executeWithHostObjects(query: string, params?: Scalar[]): Promise<QueryResult>;
    executeRawSync(query: string, params?: Scalar[]): RawQueryResult;
    executeRaw(query: string, params?: Scalar[]): Promise<RawQueryResult>;
    executeBatch(commands: SQLBatchTuple[]): Promise<BatchQueryResult>;
    loadFile(location: string): Promise<FileLoadResult>;
    transaction(fn: (tx: Transaction) => Promise<void>): Promise<void>;
    prepareStatement(query: string): PreparedStatement;
    attach(params: {
        secondaryDbFileName: string;
        alias: string;
        location?: string;
    }): void;
    detach(alias: string): void;
    updateHook(callback?: ((params: {
        table: string;
        operation: UpdateHookOperation;
        row?: any;
        rowId: number;
    }) => void) | null): void;
    commitHook(callback?: (() => void) | null): void;
    rollbackHook(callback?: (() => void) | null): void;
    loadExtension(path: string, entryPoint?: string): void;
    getDbPath(location?: string): string;
    reactiveExecute(params: {
        query: string;
        arguments: any[];
        fireOn: {
            table: string;
            ids?: number[];
        }[];
        callback: (response: any) => void;
    }): () => void;
    sync(): void;
    setReservedBytes(reservedBytes: number): void;
    getReservedBytes(): number;
    flushPendingReactiveQueries(): Promise<void>;
    close(): void;
    delete(): void;
}
//# sourceMappingURL=database.d.ts.map