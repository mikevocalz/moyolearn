import wasmAssetUrl from "@sqlite.org/sqlite-wasm/sqlite3.wasm";
export default wasmAssetUrl;
//# sourceMappingURL=opsqlite-web-wasm-asset.d.ts.map