export {};
//# sourceMappingURL=opsqlite-web.worker.d.ts.map