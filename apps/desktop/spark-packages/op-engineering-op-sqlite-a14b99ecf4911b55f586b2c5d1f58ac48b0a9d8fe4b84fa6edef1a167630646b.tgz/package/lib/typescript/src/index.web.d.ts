export * from "./functions.web";
export { Storage } from "./Storage.web";
export type { _InternalDB, _PendingTransaction, BatchQueryResult, ColumnMetadata, DB, DBParams, FileLoadResult, OPSQLiteProxy, PreparedStatement, QueryResult, Scalar, SQLBatchTuple, Transaction, UpdateHookOperation, } from "./types";
export declare const IOS_DOCUMENT_PATH = "";
export declare const IOS_LIBRARY_PATH = "";
export declare const ANDROID_DATABASE_PATH = "";
export declare const ANDROID_FILES_PATH = "";
export declare const ANDROID_EXTERNAL_FILES_PATH = "";
//# sourceMappingURL=index.web.d.ts.map