export * from "./functions";
export { Storage } from "./Storage";
export type { _InternalDB, _PendingTransaction, BatchQueryResult, ColumnMetadata, DB, DBParams, FileLoadResult, OPSQLiteProxy, PreparedStatement, QueryResult, Scalar, SQLBatchTuple, Transaction, UpdateHookOperation, } from "./types";
export declare const IOS_DOCUMENT_PATH: any, IOS_LIBRARY_PATH: any, ANDROID_DATABASE_PATH: any, ANDROID_FILES_PATH: any, ANDROID_EXTERNAL_FILES_PATH: any;
//# sourceMappingURL=index.d.ts.map