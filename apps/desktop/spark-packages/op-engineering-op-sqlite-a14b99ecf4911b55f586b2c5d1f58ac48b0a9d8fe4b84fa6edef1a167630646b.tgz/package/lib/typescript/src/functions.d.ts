import type { DB, OpenOptions, OPSQLiteProxy } from "./types";
declare global {
    var __OPSQLiteProxy: object | undefined;
}
export declare const OPSQLite: OPSQLiteProxy;
/**
 * Open a replicating/sync connection.
 * Requires libsql or turso backend to be enabled in package.json.
 */
export declare const openSync: (params: {
    url: string;
    authToken: string;
    name: string;
    location?: string;
    libsqlSyncInterval?: number;
    libsqlOffline?: boolean;
    encryptionKey?: string;
    remoteEncryptionKey?: string;
}) => DB;
/**
 * Open a remote connection.
 * Requires libsql or turso backend to be enabled in package.json.
 */
export declare const openRemote: (params: {
    url: string;
    authToken: string;
}) => DB;
/**
 * Open a connection to a local sqlite or sqlcipher database
 * If you want libsql remote or sync connections, use openSync or openRemote
 */
export declare const open: (params: OpenOptions) => DB;
/**
 * Async wrapper around open().
 * Useful for cross-platform code that also targets web where openAsync() is required.
 */
export declare const openAsync: (params: OpenOptions) => Promise<DB>;
/**
 * Moves the database from the assets folder to the default path (check the docs) or to a custom path
 * It DOES NOT OVERWRITE the database if it already exists in the destination path
 * if you want to overwrite the database, you need to pass the overwrite flag as true
 * @param args object with the parameters for the operation
 * @returns promise, rejects if failed to move the database, resolves if the operation was successful
 */
export declare const moveAssetsDatabase: (args: {
    filename: string;
    path?: string;
    overwrite?: boolean;
}) => Promise<boolean>;
/**
 * Used to load a dylib file that contains a sqlite 3 extension/plugin
 * It returns the raw path to the actual file which then needs to be passed to the loadExtension function
 * Check the docs for more information
 * @param bundle the iOS bundle identifier of the .framework
 * @param name the file name of the dylib file
 * @returns
 */
export declare const getDylibPath: (bundle: string, name: string) => string;
export declare const isSQLCipher: () => boolean;
export declare const isLibsql: () => boolean;
export declare const isTurso: () => boolean;
export declare const isIOSEmbedded: () => boolean;
//# sourceMappingURL=functions.d.ts.map