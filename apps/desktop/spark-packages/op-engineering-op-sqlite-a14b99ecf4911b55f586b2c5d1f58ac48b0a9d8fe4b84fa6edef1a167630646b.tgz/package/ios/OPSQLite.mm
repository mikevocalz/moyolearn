#import "OPSQLite.h"
#import "../cpp/OPSqlite.hpp"
#import <React/RCTBridge+Private.h>
#import <React/RCTLog.h>
#import <React/RCTUtils.h>
#import <ReactCommon/RCTTurboModule.h>
#import <jsi/jsi.h>

// RCTCxxBridge (the old-architecture class that exposed `.runtime`) no
// longer ships as of React Native 0.87 — old architecture was removed and
// `_bridge` is now an `RCTBridgeProxy` (an NSProxy) in bridgeless mode.
// RCTBridgeProxy implements `-(void *)runtime` directly (see
// React/Base/RCTBridgeProxy.mm), so a lightweight duck-typed protocol
// dodges the need to import either concrete, architecture-specific class.
@protocol OPSQLiteRuntimeProvider <NSObject>
- (void *)runtime;
@end

@interface OPSQLite () {
  // This generation's liveness flag. Set by install(), consumed by
  // invalidate() -- kept as a plain ivar (not routed through the JS
  // runtime) because invalidate() runs with no Runtime reference at all,
  // and this module instance is itself per-generation: RN constructs a
  // fresh one for every new RCTInstance.
  std::shared_ptr<std::atomic<bool>> _generationAlive;
}
@end

@implementation OPSQLite

@synthesize bridge = _bridge;

RCT_EXPORT_MODULE()

+ (BOOL)requiresMainQueueSetup {
  return YES;
}

- (NSDictionary *)constantsToExport {
  NSArray *libraryPaths = NSSearchPathForDirectoriesInDomains(
      NSLibraryDirectory, NSUserDomainMask, true);
  NSString *libraryPath = [libraryPaths objectAtIndex:0];

  NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(
      NSDocumentDirectory, NSUserDomainMask, true);
  NSString *documentPath = [documentPaths objectAtIndex:0];
  return
      @{@"IOS_DOCUMENT_PATH" : documentPath, @"IOS_LIBRARY_PATH" : libraryPath};
}

- (NSDictionary *)getConstants {
  return [self constantsToExport];
}

RCT_EXPORT_BLOCKING_SYNCHRONOUS_METHOD(install) {
  if (_bridge == nil) {
    return @false;
  }

  // `_bridge` is `RCTBridgeProxy` (an NSProxy) in bridgeless mode, which
  // implements `-(void *)runtime` directly (React/Base/RCTBridgeProxy.mm;
  // confirmed present in the compiled binary via `nm`). Both
  // `-respondsToSelector:` and `-methodSignatureForSelector:` return false
  // negatives for this method on this NSProxy subclass — its forwarding
  // machinery only accounts for selectors it dynamically forwards, not the
  // ones it implements directly — so introspecting for support isn't
  // reliable here. Since old architecture is fully removed as of RN 0.87,
  // `_bridge` is always an RCTBridgeProxy; call `-runtime` directly and
  // guard with an exception handler instead, in case that ever changes.
  facebook::jsi::Runtime *jsiRuntime = nullptr;
  @try {
    id<OPSQLiteRuntimeProvider> runtimeProvider = (id<OPSQLiteRuntimeProvider>)_bridge;
    jsiRuntime = (facebook::jsi::Runtime *)[runtimeProvider runtime];
  } @catch (NSException *exception) {
    RCTLogError(@"[OP-SQLITE] Failed to obtain the JSI runtime from the bridge: %@", exception);
    return @false;
  }
  if (jsiRuntime == nil) {
    return @false;
  }

  auto &runtime = *jsiRuntime;
  auto callInvoker = _bridge.jsCallInvoker;

  // Get appGroupID value from Info.plist using key "AppGroup"
  NSString *appGroupID =
      [[NSBundle mainBundle] objectForInfoDictionaryKey:@"OPSQLite_AppGroup"];
  NSString *documentPath;

  if (appGroupID != nil) {
    // Get the app groups container storage url
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSURL *storeUrl = [fileManager
        containerURLForSecurityApplicationGroupIdentifier:appGroupID];

    if (storeUrl == nil) {
      NSLog(@"OP-SQLite: Invalid AppGroup ID provided (%@). Check the "
            @"value of "
            @"\"AppGroup\" in your Info.plist file",
            appGroupID);
      return @false;
    }

    documentPath = [storeUrl path];
  } else {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(
        NSLibraryDirectory, NSUserDomainMask, true);
    documentPath = [paths objectAtIndex:0];
  }

#ifdef OP_SQLITE_USE_SQLITE_VEC
  NSString *sqlitevec_bundle_path =
      [[[NSBundle mainBundle] privateFrameworksPath]
          stringByAppendingPathComponent:@"sqlitevec.framework"];
  NSBundle *libsqlitevec_bundle =
      [NSBundle bundleWithPath:sqlitevec_bundle_path];
  NSString *sqlite_vec_path = [libsqlitevec_bundle pathForResource:@"sqlitevec"
                                                            ofType:@""];
#else
  NSString *sqlite_vec_path = @"";
#endif

  _generationAlive =
      opsqlite::install(runtime, callInvoker, [documentPath UTF8String],
                       [sqlite_vec_path UTF8String]);
  return @true;
}

RCT_EXPORT_BLOCKING_SYNCHRONOUS_METHOD(getDylibPath : (
    NSString *)bundleId andResource : (NSString *)resourceName) {
  NSString *bundle_path = [[[NSBundle mainBundle] privateFrameworksPath]
      stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.framework",
                                                                resourceName]];
  NSBundle *bundle = [NSBundle bundleWithPath:bundle_path];
  NSString *path = [bundle pathForResource:resourceName ofType:@""];
  return path;
}

RCT_EXPORT_METHOD(moveAssetsDatabase : (NSDictionary *)args resolve : (
    RCTPromiseResolveBlock)resolve reject : (RCTPromiseRejectBlock)reject) {
  NSString *documentPath = [NSSearchPathForDirectoriesInDomains(
      NSLibraryDirectory, NSUserDomainMask, true) objectAtIndex:0];

  NSString *filename = args[@"filename"];
  BOOL overwrite = [args[@"overwrite"] boolValue];

  NSString *sourcePath = [[NSBundle mainBundle] pathForResource:filename
                                                         ofType:nil];

  NSString *destinationPath =
      [documentPath stringByAppendingPathComponent:filename];

  NSError *error;
  NSFileManager *fileManager = [NSFileManager defaultManager];
  if ([fileManager fileExistsAtPath:destinationPath]) {
    if (overwrite) {
      [fileManager removeItemAtPath:destinationPath error:&error];
      if (error) {
        NSLog(@"Error: %@", error);
        resolve(@false);
        return;
      }
    } else {
      resolve(@true);
      return;
    }
  }

  [fileManager copyItemAtPath:sourcePath toPath:destinationPath error:&error];
  if (error) {
    NSLog(@"Error: %@", error);
    resolve(@false);
    return;
  }
  resolve(@true);
  return;
}

- (void)invalidate {
  opsqlite::invalidate(_generationAlive);
  _generationAlive = nullptr;
}

+ (void)expoUpdatesWorkaround {
  NSArray *paths = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory,
                                                       NSUserDomainMask, true);
  NSString *documentPath = [paths objectAtIndex:0];
  opsqlite::expoUpdatesWorkaround([documentPath UTF8String]);
}

@end
