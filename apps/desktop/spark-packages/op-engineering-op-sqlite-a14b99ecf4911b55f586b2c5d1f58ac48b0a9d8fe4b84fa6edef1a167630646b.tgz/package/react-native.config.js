module.exports = {};

module.exports.dependency ??= {}; module.exports.dependency.platforms ??= {};
module.exports.dependency.platforms.windows = {"sourceDir":"windows","solutionFile":"SparkOPSQLite.sln","projects":[{"projectFile":"SparkOPSQLite/SparkOPSQLite.vcxproj","directDependency":true}]};
